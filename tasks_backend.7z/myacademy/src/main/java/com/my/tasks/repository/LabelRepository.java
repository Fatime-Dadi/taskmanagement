package com.my.tasks.repository;

import com.my.tasks.entity.Label;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface LabelRepository extends JpaRepository<Label, Long> {
    @Query("SELECT l FROM Label l WHERE l.id IN :ids")
    List<Label> findByIds(@Param("ids") List<Long> ids);
}