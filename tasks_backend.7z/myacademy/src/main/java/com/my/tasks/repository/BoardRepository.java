package com.my.tasks.repository;

import com.my.tasks.entity.Board;
import com.my.tasks.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface BoardRepository extends JpaRepository<Board, Long> {
    Page<Board> findByCreator(User creator, Pageable pageable);

    Page<Board> findByCreatorAndTitleContainingIgnoreCase(User creator, String title, Pageable pageable);

    Optional<Board> findByIdAndCreator(Long id, User creator);

    @Query("SELECT COUNT(b) FROM Board b WHERE b.creator = :user")
    long countByCreator(@Param("user") User user);
}