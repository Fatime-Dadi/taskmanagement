package com.my.tasks.controller;

import com.my.tasks.dto.ColumnDto;
import com.my.tasks.entity.Columns;
import com.my.tasks.entity.User;
import com.my.tasks.services.ColumnService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/columns")
public class ColumnController {

    @Autowired
    private ColumnService columnService;

    @PostMapping
    public ResponseEntity<Columns> createColumn(
            @RequestBody ColumnDto columnDto,
            @AuthenticationPrincipal User user) {
        Columns column = columnService.createColumn(columnDto, user);
        return ResponseEntity.ok(column);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Columns> updateColumn(
            @PathVariable Long id,
            @RequestBody ColumnDto columnDto,
            @AuthenticationPrincipal User user) {
        Columns updatedColumn = columnService.updateColumn(id, columnDto, user);
        return ResponseEntity.ok(updatedColumn);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteColumn(
            @PathVariable Long id,
            @AuthenticationPrincipal User user) {
        columnService.deleteColumn(id, user);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/{id}/move")
    public ResponseEntity<Columns> moveColumn(
            @PathVariable Long id,
            @RequestParam int newPosition,
            @AuthenticationPrincipal User user) {
        Columns column = columnService.moveColumn(id, newPosition, user);
        return ResponseEntity.ok(column);
    }
}