package com.my.tasks.repository;

import com.my.tasks.entity.Columns;
import com.my.tasks.entity.Task;
import com.my.tasks.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

public interface TaskRepository extends JpaRepository<Task, Long> {
    Page<Task> findByColumn(Columns column, Pageable pageable);

    Page<Task> findByTitleContainingIgnoreCaseAndColumn_Board_Creator(String search, User creator, Pageable pageable);

    @Query("SELECT t FROM Task t WHERE t.assignedUser = :user")
    List<Task> findByAssignedUser(@Param("user") User user);

    @Query("SELECT COUNT(t) FROM Task t WHERE t.assignedUser = :user AND t.dueDate < CURRENT_DATE")
    long countOverdueTasksByUser(@Param("user") User user);

    Page<Task> findByColumn_Board_Creator(User user, Pageable pageable);

    @Query("""
        SELECT t
          FROM Task t
          JOIN t.column c
          JOIN c.board b
         WHERE t.id = :taskId
           AND b.creator = :user
    """)
    Optional<Task> findByIdAndBoardCreator(
            @Param("taskId") Long id,
            @Param("user")    User user
    );}