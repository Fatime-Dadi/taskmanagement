package com.my.tasks.controller;

import com.my.tasks.dto.BoardDto;
import com.my.tasks.entity.Board;
import com.my.tasks.entity.User;
import com.my.tasks.services.BoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/boards")
public class BoardController {

    @Autowired
    private BoardService boardService;

    @PostMapping
    public ResponseEntity<Board> createBoard(
            @RequestBody BoardDto boardDto,
            @AuthenticationPrincipal User user) {
        Board board = boardService.createBoard(boardDto, user);
        return ResponseEntity.ok(board);
    }

    @GetMapping
    public ResponseEntity<Page<Board>> getAllBoards(
            @AuthenticationPrincipal User user,
            Pageable pageable,
            @RequestParam(required = false) String search) {
        Page<Board> boards = boardService.getAllBoards(user, pageable, search);
        return ResponseEntity.ok(boards);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Board> getBoardById(
            @PathVariable Long id,
            @AuthenticationPrincipal User user) {
        Board board = boardService.getBoardByIdAndUser(id, user);
        return ResponseEntity.ok(board);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Board> updateBoard(
            @PathVariable Long id,
            @RequestBody BoardDto boardDto,
            @AuthenticationPrincipal User user) {
        Board updatedBoard = boardService.updateBoard(id, boardDto, user);
        return ResponseEntity.ok(updatedBoard);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteBoard(
            @PathVariable Long id,
            @AuthenticationPrincipal User user) {
        boardService.deleteBoard(id, user);
        return ResponseEntity.ok().build();
    }
}