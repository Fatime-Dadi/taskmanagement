package com.my.tasks.dto.user;

import com.my.tasks.enums.Role;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UpdateUserDto {
    private long id;
    private String firstName;
    private String lastName;
    private String email;
    private String address;
    private String addressLineTwo;
    private String postalCode;
    private String ville;
    private String profession;
    private String phone;
    private String companyName;
    private String function;
    private String oldPassword;
    private String newPassword;
    private Role role;
}
