package com.my.tasks.enums;

public enum VilleDuTchad {
    NDJAMENA("N'Djaména"),
    MOUNDOU("Moundou"),
    ABECHE("Abeche"),
    SARH("Sarh"),
    FAYA_LARGEAU("Faya-Largeau"),
    KOUMRA("Koumra"),
    KELO("Kélo"),
    MONGO("Mongo"),
    PALA("Pala"),
    AM_TIMAN("Am Timan"),
    ATI("Ati"),
    BONGOR("Bongor"),
    DOBA("Doba"),
    MAO("Mao"),
    OUM_HADJER("Oum Hadjer"),
    MOUSSORO("Moussoro"),
    BITKINE("Bitkine"),
    BILTINE("Biltine"),
    MASSAGUET("Massaguet"),
    DOURBALI("Dourbali"),
    LAI("Laï"),
    LERE("Léré"),
    KYABE("Kyabé"),
    MASSAKORY("Massakory"),
    BOKORO("Bokoro"),
    BOUSSO("Bousso"),
    BENOYE("Benoye"),
    BEBEDJIA("Bébédjia"),
    ADRE("Adré"),
    NGAMA("Ngama"),
    BERE("Béré"),
    FIANGA("Fianga"),
    BOL("Bol"),
    MOISSALA("Moïssala"),
    GUELENDENG("Guelendeng"),
    GOUNDI("Goundi"),
    GOUNOU_GAYA("Gounou Gaya"),
    BAIBOKOUM("Baïbokoum"),
    AOZOU("Aozou"),
    MELFI("Melfi"),
    MASSENYA("Massenya");

    private final String ville;

    VilleDuTchad(String ville) {
        this.ville = ville;
    }

    public String getVille() {
        return ville;
    }
}

