package com.my.tasks.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GlobalSearchDto {
    private List<BoardSummaryDto> boards;
    private List<TaskResultDto> tasks;

}

@Data
@AllArgsConstructor
@NoArgsConstructor
class TaskResultDto {
    private Long id;
    private String title;
    private String boardTitle;

}