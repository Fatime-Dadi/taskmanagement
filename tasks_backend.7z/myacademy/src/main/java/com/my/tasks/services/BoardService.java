package com.my.tasks.services;

import com.my.tasks.dto.BoardDto;
import com.my.tasks.entity.Board;
import com.my.tasks.entity.User;
import com.my.tasks.exception.UnauthorizedException;
import com.my.tasks.repository.BoardRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class BoardService {

    private static final Logger logger = LoggerFactory.getLogger(BoardService.class);

    @Autowired
    private BoardRepository boardRepository;

    public Board createBoard(BoardDto boardDto, User user) {
        Board board = new Board();
        board.setTitle(boardDto.getTitle());
        board.setDescription(boardDto.getDescription());
        board.setCreator(user);

        return boardRepository.save(board);
    }

    public Page<Board> getAllBoards(User user, Pageable pageable, String search) {
        if (search != null && !search.isEmpty()) {
            return boardRepository.findByCreatorAndTitleContainingIgnoreCase(user, search, pageable);
        }
        return boardRepository.findByCreator(user, pageable);
    }

    public Board getBoardByIdAndUser(Long id, User user) {
        return boardRepository.findByIdAndCreator(id, user)
                .orElseThrow(() -> new UnauthorizedException("Board not found or access denied"));
    }

    public Board updateBoard(Long id, BoardDto boardDto, User user) {
        Board board = getBoardByIdAndUser(id, user);
        board.setTitle(boardDto.getTitle());
        board.setDescription(boardDto.getDescription());

        return boardRepository.save(board);
    }

    public void deleteBoard(Long id, User user) {
        Board board = getBoardByIdAndUser(id, user);
        boardRepository.delete(board);
    }
}