package com.my.tasks.dto.user;
import lombok.Data;

@Data
public class UserFullDto extends UserDto {
    private String adresse;
    private String adresseComplementaire;
    private String codePostal;
    private String ville;
    private String telephone;
    private String etablissement;
    private String fonction;
}