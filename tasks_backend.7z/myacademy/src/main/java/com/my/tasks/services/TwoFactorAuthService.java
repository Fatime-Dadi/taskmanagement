package com.my.tasks.services;

import com.my.tasks.entity.User;
import com.my.tasks.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Random;

@Service
public class TwoFactorAuthService {

    @Autowired
    private EmailService emailService;

    @Autowired
    private UserRepository userRepository;

    private static final int CODE_LENGTH = 6;
    private static final int CODE_EXPIRY_MINUTES = 5;

    public void generateAndSend2FACode(User user) {
        String code = generateRandomCode();
        LocalDateTime expiryDate = LocalDateTime.now().plusMinutes(CODE_EXPIRY_MINUTES);

        user.setTwoFactorCode(code);
        user.setTwoFactorCodeExpiry(expiryDate);
        userRepository.save(user);

        emailService.send2FACode(user.getEmail(), code);
    }

    private String generateRandomCode() {
        Random random = new Random();
        StringBuilder code = new StringBuilder();

        for(int i = 0; i < CODE_LENGTH; i++) {
            code.append(random.nextInt(10));
        }

        return code.toString();
    }

    public boolean verify2FACode(User user, String code) {
        if (user.getTwoFactorCode() == null || user.getTwoFactorCodeExpiry() == null) return false;

        boolean notExpired = LocalDateTime.now().isBefore(user.getTwoFactorCodeExpiry());
        return notExpired && user.getTwoFactorCode().equals(code);
    }


    public void enable2FA(User user) {
        user.setTwoFactorEnabled(true);
        userRepository.save(user);
    }

    public void disable2FA(User user) {
        user.setTwoFactorEnabled(false);
        user.setTwoFactorCode(null);
        user.setTwoFactorCodeExpiry(null);
        userRepository.save(user);
    }
}