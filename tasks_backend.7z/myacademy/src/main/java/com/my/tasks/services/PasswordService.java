package com.my.tasks.services;

import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@Service
public class PasswordService {

    private static final String SALT = "TEduhfhtdghgTEtdfrfge";

    public String encodePassword(String password) {
        MessageDigest digest;
        try {
            digest = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

        String saltedPassword = SALT + password;
        System.out.println("saltedPassword: " + saltedPassword);
        byte[] hash = digest.digest(saltedPassword.getBytes(StandardCharsets.UTF_8));
        return bytesToHex(hash);
    }

    private static String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder(2 * hash.length);
        for (int i = 0; i < hash.length; i++) {
            String hex = Integer.toHexString(0xff & hash[i]);
            if(hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

    /**
     * Vérifie si un mot de passe non chiffré correspond à un mot de passe chiffré.
     *
     * @param rawPassword Le mot de passe non chiffré à vérifier.
     * @param encodedPassword Le mot de passe chiffré pour la comparaison.
     * @return true si les mots de passe correspondent, sinon false.
     */
    public boolean matches(String rawPassword, String encodedPassword) {
        // Chiffrer le mot de passe non chiffré en utilisant la même méthode de chiffrement
        String encodedRawPassword = encodePassword(rawPassword);
        // Comparer les deux mots de passe chiffrés
        return encodedRawPassword.equals(encodedPassword);
    }
}