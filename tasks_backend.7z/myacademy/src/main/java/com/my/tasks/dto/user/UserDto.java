package com.my.tasks.dto.user;
import com.my.tasks.entity.User;
import com.my.tasks.enums.Role;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserDto {
    private Long  id;
    private String lastName;
    private String firstName;
    private String email;
    private Role role;
    private String phone;
    private String street;

    public UserDto(User user) {
        this.id = user.getId();
        this.lastName = user.getLastName();
        this.firstName = user.getFirstName();
        this.email = user.getEmail();
        this.role = user.getRole();
        this.phone = user.getPhone();
        this.street = user.getStreet();
    }
}


