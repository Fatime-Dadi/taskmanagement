package com.my.tasks.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    private final Logger logger = LoggerFactory.getLogger(EmailService.class);

    public void sendPasswordResetEmail(String toEmail, String resetLink) {
        try {
            SimpleMailMessage mailMessage = new SimpleMailMessage();
            mailMessage.setFrom("no-reply@yourdomain.com");
            mailMessage.setTo(toEmail);
            mailMessage.setSubject("Password Reset");
            mailMessage.setText("Click the following link to reset your password: " + resetLink);

            mailSender.send(mailMessage);
            logger.info("[sendPasswordResetEmail] Email successfully sent to {}", toEmail);
        } catch (Exception e) {
            logger.error("[sendPasswordResetEmail] Failed to send to {}: {}", toEmail, e.getMessage(), e);
        }
    }

    public void send2FACode(String toEmail, String code) {
        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setTo(toEmail);
        mailMessage.setSubject("Your 2FA Verification Code");
        mailMessage.setText("Your verification code is: " + code);

        try {
            logger.info("Sending email to {}", toEmail);
            logger.debug("Email content: {}", mailMessage.getText());

            mailSender.send(mailMessage);
            logger.info("Email successfully sent to {}", toEmail);
        } catch (MailException e) {
            logger.error("Error while sending email to {}: {}", toEmail, e.getMessage(), e);
        }
    }

    @Async
    public void sendConversationNotification(String toEmail, String message) {
        logger.info("[sendConversationNotification] Sending notification to {}", toEmail);

        try {
            SimpleMailMessage mailMessage = new SimpleMailMessage();
            mailMessage.setFrom("no-reply@yourdomain.com");
            mailMessage.setTo(toEmail);
            mailMessage.setSubject("Notification");
            mailMessage.setText(message);

            mailSender.send(mailMessage);
            logger.info("[sendConversationNotification] Email successfully sent to {}", toEmail);
        } catch (Exception e) {
            logger.error("[sendConversationNotification] Failed to send to {}: {}", toEmail, e.getMessage(), e);
        }
    }
}
