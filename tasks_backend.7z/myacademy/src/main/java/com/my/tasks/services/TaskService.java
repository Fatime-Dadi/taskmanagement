package com.my.tasks.services;

import com.my.tasks.dto.TaskDto;

import com.my.tasks.entity.*;
import com.my.tasks.exception.UnauthorizedException;

import com.my.tasks.repository.ColumnRepository;
import com.my.tasks.repository.LabelRepository;
import com.my.tasks.repository.TaskRepository;
import com.my.tasks.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TaskService {

    private static final Logger logger = LoggerFactory.getLogger(TaskService.class);

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private LabelRepository labelRepository;

    @Autowired
    private ColumnRepository columnRepository;

    @Autowired
    private UserRepository userRepository;

    public Task createTask(TaskDto taskDto, User user) {
        Columns column = columnRepository.findById(taskDto.getColumnId())
                .orElseThrow(() -> new UnauthorizedException("Column not found"));

        if (!column.getBoard().getCreator().getId().equals(user.getId())) {
            throw new UnauthorizedException("Access denied");
        }

        Task task = new Task();
        task.setTitle(taskDto.getTitle());
        task.setDescription(taskDto.getDescription());
        task.setDueDate(taskDto.getDueDate());
        task.setPriority(Priority.valueOf(taskDto.getPriority()));
        task.setColumn(column);

        if (taskDto.getAssignedUserId() != null) {
            User assignedUser = userRepository.findById(taskDto.getAssignedUserId())
                    .orElseThrow(() -> new UnauthorizedException("User not found"));
            task.setAssignedUser(assignedUser);
        }

        if (taskDto.getLabelIds() != null) {
            List<Label> labels = labelRepository.findAllById(taskDto.getLabelIds());
            task.setLabels(labels);
        }

        return taskRepository.save(task);
    }

    public Page<Task> getAllTasks(Long columnId, String search, Pageable pageable, User user) {
        if (columnId != null) {
            Columns column = columnRepository.findById(columnId)
                    .orElseThrow(() -> new UnauthorizedException("Column not found"));

            if (!column.getBoard().getCreator().getId().equals(user.getId())) {
                throw new UnauthorizedException("Access denied");
            }

            return taskRepository.findByColumn(column, pageable);
        }

        if (search != null) {
            return taskRepository.findByTitleContainingIgnoreCaseAndColumn_Board_Creator(search, user, pageable);
        }

        return taskRepository.findByColumn_Board_Creator(user, pageable);
    }

    public Task moveTask(Long taskId, Long newColumnId, User user) {
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new UnauthorizedException("Task not found"));

        Columns newColumn = columnRepository.findById(newColumnId)
                .orElseThrow(() -> new UnauthorizedException("Column not found"));

        if (!task.getColumn().getBoard().getCreator().getId().equals(user.getId()) ||
                !newColumn.getBoard().getCreator().getId().equals(user.getId())) {
            throw new UnauthorizedException("Access denied");
        }

        task.setColumn(newColumn);
        return taskRepository.save(task);
    }

    public void deleteTask(Long id, User user) {
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new UnauthorizedException("Task not found"));

        if (!task.getColumn().getBoard().getCreator().getId().equals(user.getId())) {
            throw new UnauthorizedException("Access denied");
        }

        taskRepository.delete(task);
    }

    public Task updateTask(Long id, TaskDto dto, User user) {
        Task task = taskRepository.findByIdAndBoardCreator(id, user)
                .orElseThrow(() -> new EntityNotFoundException("Task not found"));

        // ← Update all fields from TaskDto
        task.setTitle(dto.getTitle());
        task.setDescription(dto.getDescription());
        task.setDueDate(dto.getDueDate()); // if you're handling due dates
        task.setPriority(Priority.valueOf(dto.getPriority()));

        // Parent column (if allowed to update)
        if (dto.getColumnId() != null) {
            Columns col = columnRepository.findById(dto.getColumnId())
                    .orElseThrow(() -> new EntityNotFoundException("Column not found"));
            task.setColumn(col);
        }

        // Assigned user
        if (dto.getAssignedUserId() != null) {
            User assigned = userRepository.findById(dto.getAssignedUserId())
                    .orElseThrow(() -> new EntityNotFoundException("User not found"));
            task.setAssignedUser(assigned);
        } else {
            task.setAssignedUser(null);
        }

        // Labels
        if (dto.getLabelIds() != null) {
            List<Label> labels = labelRepository.findAllById(dto.getLabelIds());
            task.setLabels(labels);
        }

        return taskRepository.save(task);
    }

    public List<Task> getTasksAssignedToUser(User user) {
        return taskRepository.findByAssignedUser(user);
    }
}
