package com.my.tasks.repository;

import com.my.tasks.entity.Board;
import com.my.tasks.entity.Columns;
import com.my.tasks.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ColumnRepository extends JpaRepository<Columns, Long> {
    List<Columns> findByBoard(Board board);

    @Query("SELECT c FROM Column c JOIN c.board b WHERE c.id = :columnId AND b.creator = :user")
    Optional<Columns> findByIdAndBoardCreator(@Param("columnId") Long columnId, @Param("user") User user);
}