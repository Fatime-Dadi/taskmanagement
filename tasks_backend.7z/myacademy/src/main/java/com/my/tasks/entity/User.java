package com.my.tasks.entity;

import com.my.tasks.dto.user.CreateUserDto;
import com.my.tasks.enums.Role;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

@Entity
@Data
@EntityListeners(AuditingEntityListener.class)
@Table(name = "utilisateur")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class User implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "nom")
    private String lastName;

    @Column(name = "prenom")
    private String firstName;

    @Column(name = "email", unique = true)
    private String email;

    @Column(name = "rue")
    private String street;

    @Column(name = "motDePasse")
    private String password;

    @Enumerated(EnumType.STRING)
    @Column(name = "role")
    private Role role;

    @Column(name = "valide")
    private Boolean valid = true;

    @Column(name = "inscriptionValide")
    private Boolean inscriptionValide = false;

    @Column(name = "ville")
    private String ville;

    @Column(name = "telephone")
    private String phone;

    @CreatedDate
    @CreationTimestamp
    @Column(name = "creation")
    private LocalDateTime creation;

    @LastModifiedDate
    @UpdateTimestamp
    @Column(name = "modification")
    private LocalDateTime modification;

    @Column(name = "auteurCreation")
    private String creationAuthor;

    @Column(name = "auteurModification")
    private String modificationAuthor;

    @Column(name = "tokenEmail")
    private String tokenEmail;

    @Column(name = "dateExpirationToken")
    private Timestamp dateExpirationToken;

    @Column(name = "profession")
    private String profession;

    @Column(name = "two_factor_enabled")
    private Boolean twoFactorEnabled = false;


    @Column(name = "two_factor_code")
    private String twoFactorCode;

    @Column(name = "two_factor_code_expiry")
    private LocalDateTime twoFactorCodeExpiry;

    @Transient
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private String token;

    public User(CreateUserDto dto, Role role) {
        super();
        this.role = role;
        this.email = dto.getEmail();
        this.password = dto.getPassword();
        this.firstName = dto.getFirstName();
        this.lastName = dto.getLastName();
        this.phone = dto.getPhone();
        this.inscriptionValide = false;
        this.ville = dto.getVille();
        this.valid = true;
        this.tokenEmail = "1234";

        switch (this.role) {
            case ROLE_ADMIN:
            case ROLE_FORMATEUR:
                this.creationAuthor = "get du token"; // @todo
                this.modificationAuthor = "get du token"; // @todo
                break;

            default:
                this.creationAuthor = this.getFullName();
                this.modificationAuthor = this.getFullName();
                break;
        }
    }

    public User(User user) {
        this.id = user.getId();
        this.lastName = user.getLastName();
        this.firstName = user.getFirstName();
        this.email = user.getEmail();
        this.password = user.getPassword();
        this.role = user.getRole();
        this.phone = user.getPhone();
        this.profession = user.getProfession();
        this.inscriptionValide = user.getInscriptionValide();
        this.ville = user.getVille();
        this.valid = user.getValid();
        this.creation = user.getCreation();
        this.modification = user.getModification();
        this.creationAuthor = user.getCreationAuthor();
        this.modificationAuthor = user.getModificationAuthor();
        this.tokenEmail = user.getTokenEmail();
        this.dateExpirationToken = user.getDateExpirationToken();
    }

    public User() {
        super();
    }

    public User(Long senderId) {
        this.id = senderId;
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        final List<SimpleGrantedAuthority> authorities = new LinkedList<>();
        Role role = Role.valueOf(getRole().name());
        authorities.add(new SimpleGrantedAuthority("ROLE_" + role.name()));
        return authorities;
    }

    @Override
    public String getUsername() {
        return email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    public boolean isTwoFactorEnabled() {
        return Boolean.TRUE.equals(this.twoFactorEnabled);
    }

    public void setTwoFactorEnabled(Boolean enabled) {
        System.out.println("✅ 2FA update : " + enabled);
        this.twoFactorEnabled = enabled;
    }
}