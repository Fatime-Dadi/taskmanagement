//package com.my.academy.repository;
//
//import com.my.academy.entity.AuditLog;
//import com.my.entity.tasks.User;
//import org.springframework.data.jpa.repository.JpaRepository;
//import java.util.List;
//
//public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
//    List<AuditLog> findByUser(User user);
//}