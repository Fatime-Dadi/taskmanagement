package com.my.tasks.services;

import com.my.tasks.dto.ColumnDto;
import com.my.tasks.entity.Board;
import com.my.tasks.entity.Columns;
import com.my.tasks.entity.User;
import com.my.tasks.exception.UnauthorizedException;
import com.my.tasks.repository.BoardRepository;
import com.my.tasks.repository.ColumnRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ColumnService {

    private static final Logger logger = LoggerFactory.getLogger(ColumnService.class);

    @Autowired
    private ColumnRepository columnRepository;

    @Autowired
    private BoardRepository boardRepository;

    public Columns createColumn(ColumnDto columnDto, User user) {
        Board board = boardRepository.findByIdAndCreator(columnDto.getBoardId(), user)
                .orElseThrow(() -> new UnauthorizedException("Board not found or access denied"));

        Columns column = new Columns();
        column.setTitle(columnDto.getTitle());
        column.setPosition(columnDto.getPosition());
        column.setBoard(board);

        return columnRepository.save(column);
    }

    public Columns updateColumn(Long id, ColumnDto columnDto, User user) {
        Columns column = columnRepository.findById(id)
                .orElseThrow(() -> new UnauthorizedException("Column not found"));

        if (!column.getBoard().getCreator().getId().equals(user.getId())) {
            throw new UnauthorizedException("Access denied");
        }

        column.setTitle(columnDto.getTitle());
        return columnRepository.save(column);
    }

    public Columns moveColumn(Long id, int newPosition, User user) {
        Columns column = columnRepository.findById(id)
                .orElseThrow(() -> new UnauthorizedException("Column not found"));

        if (!column.getBoard().getCreator().getId().equals(user.getId())) {
            throw new UnauthorizedException("Access denied");
        }

        column.setPosition(newPosition);
        return columnRepository.save(column);
    }

    public void deleteColumn(Long id, User user) {
        Columns columns = columnRepository.findById(id)
                .orElseThrow(() -> new UnauthorizedException("Column not found"));

        if (!columns.getBoard().getCreator().getId().equals(user.getId())) {
            throw new UnauthorizedException("Access denied");
        }

        columnRepository.delete(columns);
    }
}