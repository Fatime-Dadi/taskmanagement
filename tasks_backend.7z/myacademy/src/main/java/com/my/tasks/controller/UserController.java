package com.my.tasks.controller;

import com.my.tasks.dto.AuthRequest;
import com.my.tasks.dto.PasswordChangeDto;
import com.my.tasks.dto.Verify2FADto;
import com.my.tasks.dto.user.CreateUserDto;
import com.my.tasks.dto.user.UpdateUserDto;
import com.my.tasks.dto.user.UserDto;
import com.my.tasks.entity.User;
import com.my.tasks.enums.Role;
import com.my.tasks.exception.BadRequestException;
import com.my.tasks.services.EmailService;
import com.my.tasks.services.TwoFactorAuthService;
import com.my.tasks.services.UserService;
import com.my.tasks.services.auth.JwtService;
import jakarta.persistence.EntityNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class UserController {
    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    @Autowired private UserService userService;
    @Autowired private EmailService emailService;
    @Autowired private JwtService jwtService;
    @Autowired private AuthenticationManager authenticationManager;
    @Autowired private TwoFactorAuthService twoFactorAuthService;

    @PostMapping("/createUser")
    public ResponseEntity<User> createClient(@RequestBody CreateUserDto dto) {
        if (userService.emailExists(dto.getEmail())) {
            throw new BadRequestException("Ce compte existe déjà");
        }
        User savedUser = userService.createClient(dto);
        return ResponseEntity.ok(savedUser);
    }

    @PostMapping("/authenticate")
    public ResponseEntity<?> authenticateAndGetToken(@RequestBody AuthRequest authRequest) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(authRequest.getEmail(), authRequest.getPassword()));

            if (authentication.isAuthenticated()) {
                // ✅ On recharge l’utilisateur depuis la BDD pour avoir les bonnes valeurs (ex: twoFactorEnabled)
                User user = userService.findByEmail(authRequest.getEmail())
                        .orElseThrow(() -> new BadRequestException("Utilisateur non trouvé"));

                System.out.println(">> [DEBUG] 2FA actif pour cet utilisateur ? " + user.isTwoFactorEnabled());

                if (!user.getValid()) {
                    return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Compte utilisateur non valide.");
                }

                if (user.isTwoFactorEnabled()) {
                    System.out.println(">> [DEBUG] Bloc 2FA activé !");
                    twoFactorAuthService.generateAndSend2FACode(user);
                    String tempToken = jwtService.generateTempToken(user.getEmail());

                    return ResponseEntity.status(HttpStatus.PARTIAL_CONTENT)
                            .body(Map.of(
                                    "requires2FA", true,
                                    "tempToken", tempToken,
                                    "email", user.getEmail()
                            ));
                }

                String token = jwtService.generateToken(user.getEmail());
                return ResponseEntity.ok(Map.of("token", token));
            }

            throw new UsernameNotFoundException("Demande d'utilisateur invalide!");
        } catch (BadCredentialsException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Mot de passe incorrect.");
        } catch (AuthenticationException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Informations d'identification invalides");
        }
    }

    @GetMapping("/force-2fa")
    public ResponseEntity<?> force2FA(@RequestParam String email) {
        User user = userService.findByEmail(email)
                .orElseThrow(() -> new BadRequestException("Utilisateur non trouvé"));

        user.setTwoFactorEnabled(true);
        userService.saveUser(user); // <== important

        return ResponseEntity.ok("2FA activée pour " + email);
    }


    @PostMapping("/verify-2fa")
    public ResponseEntity<?> verify2FACode(@RequestBody Verify2FADto verify2FADto) {
        try {
            User user = userService.findByEmail(verify2FADto.getEmail())
                    .orElseThrow(() -> new BadRequestException("Utilisateur non trouvé"));

            // Vérifier la validité du token temporaire
            if (!jwtService.validateToken(verify2FADto.getTempToken(), user.getEmail())) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Token temporaire invalide ou expiré.");
            }


            if (twoFactorAuthService.verify2FACode(user, verify2FADto.getCode())) {
                String token = jwtService.generateToken(user.getEmail());

                user.setTwoFactorCode(null);
                user.setTwoFactorCodeExpiry(null);
                userService.saveUser(user);

                return ResponseEntity.ok(Map.of("token", token));
            }

            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Code 2FA invalide ou expiré");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erreur lors de la vérification 2FA");
        }
    }


    @PostMapping("/resend-2fa")
    public ResponseEntity<?> resend2FACode(@RequestBody Verify2FADto verify2FADto) {
        try {
            User user = userService.findByEmail(verify2FADto.getEmail())
                    .orElseThrow(() -> new BadRequestException("Utilisateur non trouvé"));

            twoFactorAuthService.generateAndSend2FACode(user);

            return ResponseEntity.ok(Map.of(
                    "message", "Un nouveau code de vérification a été envoyé à votre email"
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Erreur lors de l'envoi du code 2FA");
        }
    }

    @PostMapping("/toggle-2fa")
    public ResponseEntity<?> toggle2FA(@AuthenticationPrincipal User user,
                                       @RequestParam boolean enable) {
        if (enable) {
            twoFactorAuthService.enable2FA(user);
            return ResponseEntity.ok("2FA activé avec succès");
        } else {
            twoFactorAuthService.disable2FA(user);
            return ResponseEntity.ok("2FA désactivé avec succès");
        }
    }

    @GetMapping("/user")
    public ResponseEntity<UserDto> getCurrentUser(@RequestHeader("Authorization") String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
        }

        String token = authHeader.substring(7); // remove "Bearer "
        String email = jwtService.extractUsername(token);

        if (email == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
        }

        User user = userService.findByEmail(email)
                .orElseThrow(() -> new BadRequestException("Utilisateur non trouvé"));

        return ResponseEntity.ok(new UserDto(user));
    }


    @PostMapping("/checkEmail")
    public ResponseEntity<?> checkEmail(@RequestBody Map<String, String> payload) {
        boolean exists = userService.emailExists(payload.get("email"));
        return ResponseEntity.ok(Map.of("exists", exists));
    }

    @PostMapping("/checkPassword")
    public ResponseEntity<?> checkPassword(@RequestBody Map<String, String> payload) {
        String email = payload.get("email");
        String password = payload.get("password");
        boolean valid = userService.checkPassword(email, password);
        return ResponseEntity.ok(Map.of("valid", valid));
    }

    @PostMapping("/request-password-reset")
    public ResponseEntity<?> requestPasswordReset(@RequestBody Map<String, String> body) {
        String email = body.get("email");
        if (email == null || email.isEmpty()) {
            return ResponseEntity.badRequest().body("L'e-mail est requis.");
        }
        try {
            String resetLink = userService.generatePasswordResetLink(email);
            emailService.sendPasswordResetEmail(email, resetLink);
            return ResponseEntity.ok("Un lien de réinitialisation a été envoyé à votre e-mail.");
        } catch (BadRequestException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestBody Map<String, String> body) {
        String token = body.get("token");
        String newPassword = body.get("newPassword");

        if (token == null || token.isEmpty() || newPassword == null || newPassword.isEmpty()) {
            return ResponseEntity.badRequest().body("Token et nouveau mot de passe sont requis.");
        }
        if (!userService.isPasswordResetTokenValid(token)) {
            return ResponseEntity.badRequest().body("Token invalide ou expiré.");
        }
        userService.resetPassword(token, newPassword);
        return ResponseEntity.ok("Mot de passe réinitialisé avec succès.");
    }

    @PostMapping("/changePassword")
    public ResponseEntity<?> changePassword(@AuthenticationPrincipal User user,
                                            @RequestBody PasswordChangeDto passwordChangeDto) {
        try {
            userService.changePassword(user, passwordChangeDto.getOldPassword(),
                    passwordChangeDto.getNewPassword());
            return ResponseEntity.ok("Mot de passe modifié avec succès.");
        } catch (BadRequestException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/user/{id}")
    public ResponseEntity<?> getUserById(@PathVariable Long id) {
        try {
            User user = userService.getUserById(id);
            return ResponseEntity.ok(user);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/activateDeactivateUser/{id}")
    public ResponseEntity<String> activateDeactivateUser(
            @PathVariable Long id,
            @RequestParam boolean isActive
    ) {
        userService.activateDeactivateUser(id, isActive);
        String statut = isActive ? "activé" : "désactivé";
        return ResponseEntity.ok("Utilisateur " + statut + " avec succès");
    }

    @PutMapping("/updateUser/{id}")
    public ResponseEntity<User> updateUser(@PathVariable long id,
                                           @RequestBody UpdateUserDto updateUserDto) {
        updateUserDto.setId(id);
        User updatedUser = userService.updateUser(updateUserDto);
        return ResponseEntity.ok(updatedUser);
    }

    @PutMapping("/disableUser/{id}")
    public ResponseEntity<?> disableUser(@PathVariable Long id) {
        userService.disableUser(id);
        return ResponseEntity.ok("Utilisateur désactivé avec succès");
    }

    @PutMapping("/changeUserRole/{id}")
    public ResponseEntity<?> changeUserRole(@PathVariable Long id,
                                            @RequestBody String newRole) {
        Role role = Role.valueOf(newRole.toUpperCase());
        userService.changeUserRole(id, role);
        return ResponseEntity.ok("Rôle de l'utilisateur mis à jour avec succès");
    }

    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @DeleteMapping("/deleteUser/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        try {
            userService.deleteUser(id);
            return ResponseEntity.ok("Utilisateur supprimé avec succès");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Erreur lors de la suppression: " + e.getMessage());
        }
    }
}