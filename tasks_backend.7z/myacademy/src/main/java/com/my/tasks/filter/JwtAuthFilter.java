package com.my.tasks.filter;

import com.my.tasks.config.UserInfoUserDetailsService;
import com.my.tasks.services.auth.JwtService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class JwtAuthFilter extends OncePerRequestFilter {

    @Autowired
    private JwtService jwtService;

    @Autowired
    private UserInfoUserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        String authHeader = request.getHeader("Authorization");
        String token = null;
        String username = null;

//        System.out.println("Filtre JWT déclenché");

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            System.out.println("Header d'autorisation trouvé: " + authHeader);

            token = authHeader.substring(7);
            username = jwtService.extractUsername(token);
        }

        if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            System.out.println("Name user extrait du JWT: " + username);

            UserDetails userDetails = userDetailsService.loadUserByUsername(username);

            // Valide le Token JWT
            if (jwtService.validateToken(token, userDetails)) {
                System.out.println("Token JWT validated with succès.");
            } else {
                System.out.println("failed validated token JWT.");
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                response.getWriter().write("Invalid JWT token");
                return;
            }

            // Vérifie l'authentification
            UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
            SecurityContextHolder.getContext().setAuthentication(authToken);
            System.out.println("Objet d'authentification fin of sécurity: " + authToken);

            // Vérifie les autorisations
            System.out.println("Autorisations bind at user: " + userDetails.getAuthorities());

        }

        // Vérifier le comportement après le filtre
        filterChain.doFilter(request, response);
//        System.out.println("Requête passée au filtre suivant ou au point d'entrée.");
    }

}