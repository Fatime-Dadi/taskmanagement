package com.my.tasks.services;

import com.my.tasks.dto.CommentDto;
import com.my.tasks.entity.Comment;
import com.my.tasks.entity.Task;
import com.my.tasks.entity.User;
import com.my.tasks.exception.UnauthorizedException;
import com.my.tasks.repository.CommentRepository;
import com.my.tasks.repository.TaskRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class CommentService {

    private static final Logger logger = LoggerFactory.getLogger(CommentService.class);

    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private TaskRepository taskRepository;

    public Comment createComment(CommentDto commentDto, User user) {
        Task task = taskRepository.findById(commentDto.getTaskId())
                .orElseThrow(() -> new UnauthorizedException("Task not found"));

        Comment comment = new Comment();
        comment.setContent(commentDto.getContent());
        comment.setTask(task);
        comment.setAuthor(user);
        comment.setCreatedAt(LocalDateTime.now());

        return commentRepository.save(comment);
    }

    public List<Comment> getCommentsByTask(Long taskId) {
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new UnauthorizedException("Task not found"));

        return commentRepository.findByTaskOrderByCreatedAtDesc(task);
    }

    public void deleteComment(Long id, User user) {
        Comment comment = commentRepository.findById(id)
                .orElseThrow(() -> new UnauthorizedException("Comment not found"));

        if (!comment.getAuthor().getId().equals(user.getId())) {
            throw new UnauthorizedException("Access denied");
        }

        commentRepository.delete(comment);
    }
}