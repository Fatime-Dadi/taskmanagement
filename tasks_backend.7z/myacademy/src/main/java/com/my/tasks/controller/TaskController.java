package com.my.tasks.controller;

import com.my.tasks.dto.TaskDto;
import com.my.tasks.entity.Task;
import com.my.tasks.entity.User;
import com.my.tasks.services.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    @Autowired
    private TaskService taskService;

    @PostMapping
    public ResponseEntity<Task> createTask(
            @RequestBody TaskDto taskDto,
            @AuthenticationPrincipal User user) {
        Task task = taskService.createTask(taskDto, user);
        return ResponseEntity.ok(task);
    }

    @GetMapping
    public ResponseEntity<Page<Task>> getAllTasks(
            @RequestParam(required = false) Long columnId,
            @RequestParam(required = false) String search,
            Pageable pageable,
            @AuthenticationPrincipal User user) {
        Page<Task> tasks = taskService.getAllTasks(columnId, search, pageable, user);
        return ResponseEntity.ok(tasks);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Task> updateTask(
            @PathVariable Long id,
            @RequestBody TaskDto taskDto,
            @AuthenticationPrincipal User user) {
        Task updatedTask = taskService.updateTask(id, taskDto, user);
        return ResponseEntity.ok(updatedTask);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteTask(
            @PathVariable Long id,
            @AuthenticationPrincipal User user) {
        taskService.deleteTask(id, user);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/{id}/move")
    public ResponseEntity<Task> moveTask(
            @PathVariable Long id,
            @RequestParam Long newColumnId,
            @AuthenticationPrincipal User user) {
        Task task = taskService.moveTask(id, newColumnId, user);
        return ResponseEntity.ok(task);
    }

    @GetMapping("/assigned")
    public ResponseEntity<List<Task>> getAssignedTasks(@AuthenticationPrincipal User user) {
        List<Task> tasks = taskService.getTasksAssignedToUser(user);
        return ResponseEntity.ok(tasks);
    }
}