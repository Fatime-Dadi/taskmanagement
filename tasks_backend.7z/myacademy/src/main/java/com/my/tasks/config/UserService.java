package com.my.tasks.config;

import com.my.tasks.entity.User;

import java.util.Optional;

public interface UserService {
    // ... autres méthodes

    Optional<User> findByEmail(String email);
    User saveUser(User user);
    void enable2FA(User user);
    void disable2FA(User user);
}
