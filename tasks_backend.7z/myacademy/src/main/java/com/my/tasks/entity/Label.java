package com.my.tasks.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "label")
public class Label {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String color;  // Ex: "#FF0000" pour rouge
}