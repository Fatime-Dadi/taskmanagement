package com.my.tasks.enums;
import com.fasterxml.jackson.annotation.JsonCreator;

public enum Role {
    ROLE_ADMIN("ADMIN"),
    ROLE_FORMATEUR("FORMATEUR"),
    ROLE_ETUDIANT("ETUDIANT"),
    PUBLIC("PUBLIC");

    private String role;

    Role(String role) {
        this.role = role;
    }

    @JsonCreator
    public static Role fromValue(String value) {
        for (Role role : values()) {
            if (role.role.equalsIgnoreCase(value)) {
                return role;
            }
        }
        throw new IllegalArgumentException("Invalid role: " + value);
    }
}
