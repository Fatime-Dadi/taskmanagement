package com.my.tasks.config;

import com.my.tasks.services.PasswordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class CustomPasswordEncoder implements PasswordEncoder {
    @Autowired
    private PasswordService passwordService;

    @Override
    public String encode(CharSequence rawPassword) {
        return passwordService.encodePassword(rawPassword.toString());
    }

    @Override
    public boolean matches(CharSequence rawPassword, String encodedPassword) {
        return passwordService.encodePassword(rawPassword.toString()).equals(encodedPassword);
    }
}
