package com.my.tasks.services;

import com.my.tasks.dto.LabelDto;
import com.my.tasks.entity.Label;
import com.my.tasks.repository.LabelRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LabelService {

    private static final Logger logger = LoggerFactory.getLogger(LabelService.class);

    @Autowired
    private LabelRepository labelRepository;

    public Label createLabel(LabelDto labelDto) {
        Label label = new Label();
        label.setName(labelDto.getName());
        label.setColor(labelDto.getColor());

        return labelRepository.save(label);
    }

    public List<Label> getAllLabels() {
        return labelRepository.findAll();
    }

    public void deleteLabel(Long id) {
        labelRepository.deleteById(id);
    }
}