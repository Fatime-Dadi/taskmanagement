package com.my.tasks.entity;

public enum Priority {
    LOW, MEDIUM, HIGH
}
