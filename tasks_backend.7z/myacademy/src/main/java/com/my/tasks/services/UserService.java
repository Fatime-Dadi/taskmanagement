package com.my.tasks.services;

import com.my.tasks.dto.user.CreateUserDto;
import com.my.tasks.dto.user.UpdateUserDto;
import com.my.tasks.entity.User;
import com.my.tasks.enums.Role;
import com.my.tasks.exception.BadRequestException;
import com.my.tasks.exception.NotFoundException;
import com.my.tasks.repository.UserRepository;
import com.my.tasks.services.auth.JwtService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserService.class);
    private static final int TOKEN_EXPIRATION_HOURS = 2;

    private final UserRepository userRepository;
    private final PasswordService passwordService;
    private final JwtService jwtService;

    @Autowired
    public UserService(UserRepository userRepository,
                       PasswordService passwordService,
                       JwtService jwtService) {
        this.userRepository = userRepository;
        this.passwordService = passwordService;
        this.jwtService = jwtService;
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public boolean emailExists(String email) {
        return userRepository.findByEmail(email).isPresent();
    }

    public boolean checkPassword(String email, String password) {
        return userRepository.findByEmail(email)
                .map(user -> passwordService.matches(password, user.getPassword()))
                .orElse(false);
    }

    public User getUserById(long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("User not found for ID: " + id));
    }

    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public User saveUser(User user) {
        try {
            return userRepository.save(user);
        } catch (DataIntegrityViolationException e) {
            logger.error("Error saving user: {}", e.getMessage());
            throw new BadRequestException("Email already exists");
        }
    }

    public String generatePasswordResetLink(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new BadRequestException("No user found with this email"));

        String resetToken = jwtService.generateToken(email);
        user.setTokenEmail(resetToken);
        user.setDateExpirationToken(Timestamp.valueOf(LocalDateTime.now().plusHours(TOKEN_EXPIRATION_HOURS)));
        userRepository.save(user);

        return "http://localhost:3000/reset-password?token=" + resetToken;
    }

    public boolean isPasswordResetTokenValid(String token) {
        return userRepository.findByTokenEmail(token)
                .map(user -> !user.getDateExpirationToken().before(Timestamp.valueOf(LocalDateTime.now())))
                .orElse(false);
    }

    public void resetPassword(String token, String newPassword) {
        User user = userRepository.findByTokenEmail(token)
                .orElseThrow(() -> new BadRequestException("Invalid token"));

        user.setPassword(passwordService.encodePassword(newPassword));
        user.setTokenEmail(null);
        user.setDateExpirationToken(null);
        userRepository.save(user);
    }

    public User updateUser(UpdateUserDto updateUserDto) {
        User user = userRepository.findById(updateUserDto.getId())
                .orElseThrow(() -> new NotFoundException("User not found for ID: " + updateUserDto.getId()));

        updateUserFields(user, updateUserDto);

        if (updateUserDto.getOldPassword() != null && updateUserDto.getNewPassword() != null) {
            changePassword(user, updateUserDto.getOldPassword(), updateUserDto.getNewPassword());
        }

        return userRepository.save(user);
    }

    private void updateUserFields(User user, UpdateUserDto dto) {
        user.setFirstName(dto.getFirstName());
        user.setLastName(dto.getLastName());
        user.setEmail(dto.getEmail());
        user.setPhone(dto.getPhone());
        user.setProfession(dto.getProfession());
        user.setVille(dto.getVille());

        if (dto.getRole() != null) {
            user.setRole(dto.getRole());
        }
    }

    public void changePassword(User user, String oldPassword, String newPassword) {
        if (!passwordService.matches(oldPassword, user.getPassword())) {
            throw new BadRequestException("Old password is incorrect");
        }
        user.setPassword(passwordService.encodePassword(newPassword));
    }

    public User disableUser(Long id) {
        User user = getUserById(id);
        user.setValid(false);
        return userRepository.save(user);
    }

    public User changeUserRole(Long id, Role role) {
        User user = getUserById(id);
        user.setRole(role);
        return userRepository.save(user);
    }

    public void deleteUser(Long id) {
        if (!userRepository.existsById(id)) {
            throw new NotFoundException("User not found for ID: " + id);
        }
        userRepository.deleteById(id);
    }

    public User activateDeactivateUser(Long id, boolean isActive) {
        User user = getUserById(id);
        user.setValid(isActive);
        return userRepository.save(user);
    }

    public User createClient(CreateUserDto dto) {
        if (emailExists(dto.getEmail())) {
            throw new BadRequestException("Email already exists");
        }

        User user = new User(dto, Role.PUBLIC);
        user.setPassword(passwordService.encodePassword(dto.getPassword()));
        user.setTwoFactorEnabled(true);

        return userRepository.save(user);
    }

    public void enable2FA(User user) {
        user.setTwoFactorEnabled(true);
        userRepository.save(user);
    }

    public void disable2FA(User user) {
        user.setTwoFactorEnabled(false);
        user.setTwoFactorCode(null);
        user.setTwoFactorCodeExpiry(null);
        userRepository.save(user);
    }
}