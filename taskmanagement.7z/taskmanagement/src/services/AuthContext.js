// ✅ AuthContext.jsx complet avec correctif
import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
import { jwtDecode } from 'jwt-decode';
import { useNavigate } from 'react-router-dom';

const API_URL = 'http://localhost:8080/api';
const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);
  const [isUserLoggedIn, setIsUserLoggedIn] = useState(false);
  const [requires2FA, setRequires2FA] = useState(false);
  const [tempToken, setTempToken] = useState('');
  const [loading, setLoading] = useState(true);
  const [hasJustLoggedIn, setHasJustLoggedIn] = useState(false);

  const isTokenExpired = (token) => {
    if (!token) return true;
    try {
      const decoded = jwtDecode(token);
      return decoded.exp * 1000 < Date.now();
    } catch (error) {
      return true;
    }
  };

  const getToken = () => localStorage.getItem('authToken') || '';

  const authenticateByToken = async () => {
    try {
      const response = await axios.get(`${API_URL}/user`, {
        headers: { Authorization: `Bearer ${getToken()}` }
      });
      return response.data;
    } catch {
      return null;
    }
  };

  const initLogin = async () => {
    const token = getToken();
    if (token && !isTokenExpired(token)) {
      const user = await authenticateByToken();
      if (user) {
        setCurrentUser(user);
        setIsUserLoggedIn(true);
      }
    }
    setLoading(false);
  };

  const authenticate = async (email, password) => {
    try {
      const response = await axios.post(`${API_URL}/authenticate`, { email, password });

      if (response.data.requires2FA) {
        setRequires2FA(true);
        setTempToken(response.data.tempToken);
        return { requires2FA: true };
      }

      const token = response.data.token;
      localStorage.setItem('authToken', token);

      const userResponse = await axios.get(`${API_URL}/user`, {
        headers: { Authorization: `Bearer ${token}` }
      });

      const user = userResponse.data;
      setCurrentUser(user);
      setIsUserLoggedIn(true);
      setHasJustLoggedIn(true); // ✅ déclenche re-render navbar

      return { success: true };
    } catch (error) {
      throw error;
    }
  };

  const verify2FA = async (email, code) => {
    try {
      const response = await axios.post(`${API_URL}/verify-2fa`, { email, code, tempToken });
      localStorage.setItem('authToken', response.data.token);
      setRequires2FA(false);
      await initLogin();
      return { success: true };
    } catch (error) {
      throw error;
    }
  };

  const logout = () => {
    localStorage.removeItem('authToken');
    setCurrentUser(null);
    setIsUserLoggedIn(false);
    setRequires2FA(false);
    navigate('/login');
  };

  useEffect(() => {
    initLogin();
  }, []);

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isUserLoggedIn,
        requires2FA,
        authenticate,
        verify2FA,
        logout,
        initLogin,
        tempToken,
        loading,
        hasJustLoggedIn,
        setHasJustLoggedIn,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};