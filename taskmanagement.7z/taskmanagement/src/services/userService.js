


  const API_URL = 'http://localhost:8080/api';

  const headers = {
    'Content-Type': 'application/json'
  };

  async function handleResponse(response) {
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || 'Erreur inconnue');
    }
    return response.json();
  }


  export const createUser = async (dto) => {
    console.log("📤 Envoi de POST /createUser avec :", dto);
    const response = await fetch(`${API_URL}/createUser`, {
      method: 'POST',
      headers,
      body: JSON.stringify(dto),
    });
    console.log("📥 Réponse brute de /createUser :", response);
    return handleResponse(response);
  };


  export const getAllActesDeNaissance = async () => {
    const response = await fetch(`${API_URL}/actesDeNaissance`);
    return handleResponse(response);
  };

  export const emailAlreadyExists = async (email) => {
    const response = await fetch(`${API_URL}/checkEmail`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ email }),
    });
    const data = await handleResponse(response);
    return data.exists ? { alreadyExists: true } : null;
  };

  export const passwordIsCorrect = async (email, password) => {
    const response = await fetch(`${API_URL}/checkPassword`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ email, password }),
    });
    const data = await handleResponse(response);
    return !data.exists ? { incorrectPassword: true } : null;
  };

  export const emailDoesNotExist = async (email) => {
    const response = await fetch(`${API_URL}/checkEmail`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ email }),
    });
    const data = await handleResponse(response);
    return !data.exists ? { doesNotExist: true } : null;
  };

  export const getUserById = async (id) => {
    const response = await fetch(`${API_URL}/user/${id}`, {
      method: 'GET',
      headers,
    });
    return handleResponse(response);
  };

  export const updateUser = async (id, userData) => {
    const response = await fetch(`${API_URL}/updateUser/${id}`, {
      method: 'PUT',
      headers,
      body: JSON.stringify(userData),
    });
    return handleResponse(response);
  };

  export const changePassword = async (passwordChangeDto) => {
    const response = await fetch(`${API_URL}/changePassword`, {
      method: 'POST',
      headers,
      body: JSON.stringify(passwordChangeDto),
    });
    return handleResponse(response);
  };

  export const disableUser = async (id) => {
    const response = await fetch(`${API_URL}/disableUser/${id}`, {
      method: 'PUT',
      headers,
    });
    return handleResponse(response);
  };

  export const changeUserRole = async (id, newRole) => {
    const response = await fetch(`${API_URL}/changeUserRole/${id}`, {
      method: 'PUT',
      headers,
      body: JSON.stringify(newRole),
    });
    return handleResponse(response);
  };

  export const getAllUsers = async () => {
    const response = await fetch(`${API_URL}/users`, {
      method: 'GET',
      headers,
    });
    return handleResponse(response);
  };

  export const deleteUser = async (id) => {
    try {
      const response = await fetch(`${API_URL}/deleteUser/${id}`, {
        method: 'DELETE',
        headers,
      });
      return handleResponse(response);
    } catch (error) {
      console.error('Erreur lors de la suppression', error);
      throw new Error("Erreur lors de la suppression de l'utilisateur.");
    }
  };

  export const activateDeactivateUser = async (id, isActive) => {
    const response = await fetch(`${API_URL}/activateDeactivateUser/${id}`, {
      method: 'PUT',
      headers,
      body: JSON.stringify({ active: isActive }),
    });
    return handleResponse(response);
  };


  export default {
    createUser,
    getAllActesDeNaissance,
    emailAlreadyExists,
    passwordIsCorrect,
    emailDoesNotExist,
    getUserById,
    updateUser,
    changePassword,
    disableUser,
    changeUserRole,
    getAllUsers,
    deleteUser,
    activateDeactivateUser,
    handleResponse,
    

  };