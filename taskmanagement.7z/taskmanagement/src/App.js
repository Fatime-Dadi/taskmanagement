import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './services/AuthContext';
import Sidebar from './components/Sidebar/Sidebar';
import Footer from './components/Footer/Footer';
import Home from './components/Home/Home';
import Dashboard from './components/Dashboard/Dashboard';
import Login from './components/Login/Login';
import Verify2FA from './components/Login/Verify2FA';
import RequestPasswordReset from './components/ResetPassword/RequestPasswordReset';
import ResetPassword from './components/ResetPassword/ResetPassword';
import Register from './components/Register/Register';
import BoardsPage from './components/Boards/BoardsPage';
import BoardDetail from './components/BoardDetail/BoardDetail';
import UsersPage from './components/Users/UsersPage';
import './App.css';

const App = () => {
  const { loading } = useAuth();

  if (loading) {
    return <div className="text-center mt-5">Loading...</div>;
  }

  return (
    <div className="app-layout">
      <Sidebar />

      <div className="main-content">
        <Routes>
          <Route path="/" element={<Navigate to="/login" replace />} />
          <Route path="/home" element={<Home />} />
          <Route path="/dashboard" element={<Dashboard />} />

          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/verify-2fa" element={<Verify2FA />} />
          <Route path="/request-password-reset" element={<RequestPasswordReset />} />
          <Route path="/reset-password" element={<ResetPassword />} />
          <Route path="/users" element={<UsersPage />} />

          <Route path="/boards" element={<BoardsPage />} />
          <Route path="/boards/:id" element={<BoardDetail />} />
          {/* autres routes */}
        </Routes>

        <Footer />
      </div>
    </div>
  );
};

export default App;
