import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { FaCheckCircle, FaExclamationCircle, FaSpinner } from 'react-icons/fa';
import userService from '../../services/userService';
import './Register.css';

const Register = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    ville: ''
  });

  const [status, setStatus] = useState({
    loading: false,
    success: null,
    error: null
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const errors = {};
    if (!formData.firstName) errors.firstName = 'First name required';
    if (!formData.lastName) errors.lastName = 'Last name required';
    if (!formData.email) {
      errors.email = 'Email required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = 'Invalid email';
    }
    if (!formData.password) {
      errors.password = 'Password required';
    } else if (formData.password.length < 8) {
      errors.password = 'Minimum 8 characters';
    }
    if (formData.password !== formData.confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
    }
    return errors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errors = validateForm();
    
    if (Object.keys(errors).length > 0) {
      setStatus({ loading: false, error: Object.values(errors)[0] });
      return;
    }

    setStatus({ loading: true, success: null, error: null });

    try {
      // Remove confirmPassword from the data sent to the server
      const { confirmPassword, ...userData } = formData;
      const createdUser = await userService.createUser(userData);
      
      setStatus({ 
        loading: false, 
        success: 'Account created successfully! Redirecting...',
        error: null 
      });

      setTimeout(() => {
        navigate('/login', {
          state: { 
            newAccount: true,
            email: formData.email 
          }
        });
      }, 2000);

      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        password: '',
        confirmPassword: '',
        phone: '',
        ville: ''
      });

    } catch (error) {
      setStatus({ 
        loading: false, 
        success: null, 
        error: error.response?.data?.message || 'Error creating account' 
      });
    }
  };

  return (
    <div className="account-container">
      <div className="account-card">
        <div className="account-header">
          <h2>Create an account</h2>
          <p>Start your journey with us</p>
        </div>

        <form className="account-form" onSubmit={handleSubmit} noValidate>
          <div className="form-grid">
            <div className="form-group">
              <label htmlFor="firstName">First Name*</label>
              <input
                id="firstName"
                name="firstName"
                type="text"
                value={formData.firstName}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="lastName">Last Name*</label>
              <input
                id="lastName"
                name="lastName"
                type="text"
                value={formData.lastName}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="email">Email*</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password*</label>
            <input
              id="password"
              name="password"
              type="password"
              value={formData.password}
              onChange={handleChange}
              required
              minLength="8"
            />
            <small className="password-hint">Minimum 8 characters</small>
          </div>

          <div className="form-group">
            <label htmlFor="confirmPassword">Confirm Password*</label>
            <input
              id="confirmPassword"
              name="confirmPassword"
              type="password"
              value={formData.confirmPassword}
              onChange={handleChange}
              required
              minLength="8"
            />
          </div>

          <div className="form-grid">
            <div className="form-group">
              <label htmlFor="phone">Phone</label>
              <input
                id="phone"
                name="phone"
                type="tel"
                value={formData.phone}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label htmlFor="ville">City</label>
              <input
                id="ville"
                name="ville"
                type="text"
                value={formData.ville}
                onChange={handleChange}
              />
            </div>
          </div>

          <button 
            type="submit" 
            className="submit-btn"
            disabled={status.loading}
          >
            {status.loading ? (
              <>
                <FaSpinner className="spinner" />
                Creating account...
              </>
            ) : (
              'Create my account'
            )}
          </button>

          {status.success && (
            <div className="alert success">
              <FaCheckCircle className="icon" />
              {status.success}
            </div>
          )}

          {status.error && (
            <div className="alert error">
              <FaExclamationCircle className="icon" />
              {status.error}
            </div>
          )}
        </form>

        <div className="account-footer">
          <p>Already have an account? <Link to="/login">Sign in</Link></p>
        </div>
      </div>
    </div>
  );
};

export default Register;