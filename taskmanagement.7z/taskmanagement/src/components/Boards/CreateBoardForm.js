import React, { useState } from 'react';
import axios from 'axios';
import './CreateBoardForm.css';

const CreateBoardForm = ({ onBoardCreated }) => {
  const [form, setForm] = useState({ title: '', description: '' });
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title.trim()) {
      setError('Title is required.');
      return;
    }

    try {
      const token = localStorage.getItem('authToken');
      const response = await axios.post('http://localhost:8080/api/boards', form, {
        headers: { Authorization: `Bearer ${token}` }
      });
      onBoardCreated(response.data);
      setForm({ title: '', description: '' });
      setError('');
    } catch (err) {
      console.error('Error creating board:', err);
      setError('Failed to create board.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="create-board-form">
      <div className="mb-3">
        <label htmlFor="title" className="form-label">Title</label>
        <input
          type="text"
          name="title"
          id="title"
          className="form-control"
          value={form.title}
          onChange={handleChange}
        />
      </div>
      <div className="mb-3">
        <label htmlFor="description" className="form-label">Description</label>
        <textarea
          name="description"
          id="description"
          className="form-control"
          value={form.description}
          onChange={handleChange}
        ></textarea>
      </div>
      {error && <div className="text-danger mb-2">{error}</div>}
      <button type="submit" className="btn btn-primary">Create Board</button>
    </form>
  );
};

export default CreateBoardForm;
