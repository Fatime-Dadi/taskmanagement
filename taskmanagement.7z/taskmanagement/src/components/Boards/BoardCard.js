import React from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../services/AuthContext";
import "./BoardCard.css";

const BoardCard = ({ board }) => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();

  // Vérification que board et board.columns existent
  const columns = board?.columns || [];

  const assignedTasks =
    currentUser?.role === "PUBLIC"
      ? columns.flatMap((col) =>
          col.tasks?.filter((task) => task.assignedUser?.id === currentUser.id) || []
        )
      : columns.flatMap((col) => col.tasks || []);

  return (
    <div className="board-card" onClick={() => navigate(`/boards/${board.id}`)}>
      <div className="board-card-body">
        <h5>{board.title}</h5>
        <p>{board.description}</p>

        {/* Affichage du nombre de tâches assignées */}
        <small>
          {currentUser?.role === "PUBLIC"
            ? `${assignedTasks.length} tâche(s) assignée(s)`
            : `${assignedTasks.length} tâche(s) au total`}
        </small>
      </div>
    </div>
  );
};

export default BoardCard;
