import React, { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "../../services/AuthContext";
import BoardCard from "./BoardCard";
import CreateBoardForm from "./CreateBoardForm";
import "./BoardsPage.css";

const BoardsPage = () => {
  const { currentUser } = useAuth();
  const [boards, setBoards] = useState([]);

  console.log("🟢 BoardsPage render — currentUser:", currentUser);

  useEffect(() => {
    const fetchBoards = async () => {
      console.log("🛠️ BoardsPage fetchBoards triggered");
      try {
        const token = localStorage.getItem("authToken");
        console.log("🔐 BoardsPage token:", token);
        const res = await axios.get("http://localhost:8080/api/boards", {
          headers: { Authorization: `Bearer ${token}` },
        });
        console.log("📦 BoardsPage full response:", res);

        const allBoards = res.data.content || res.data;
        console.log("📋 BoardsPage allBoards:", allBoards);

        console.log("🔐 currentUser.role =", currentUser?.role);
        if (currentUser?.role === "ROLE_PUBLIC") {
          console.log("🔍 Filtering boards for PUBLIC user");
          const filtered = allBoards
            .map((board) => {
              console.log("→ Processing board", board.id);
              const cols = board.columns
                .map((col) => {
                  const tasks = col.tasks?.filter(
                    (t) => t.assignedUser?.id === currentUser.id
                  );
                  console.log(`   • Column ${col.id} tasks for user:`, tasks);
                  return { ...col, tasks };
                })
                .filter((col) => col.tasks.length > 0);
              console.log("   • Filtered columns:", cols);
              return cols.length > 0 ? { ...board, columns: cols } : null;
            })
            .filter(Boolean);
          console.log("✅ BoardsPage filteredBoards (PUBLIC):", filtered);
          setBoards(filtered);
        } else {
          console.log("✅ BoardsPage boards for ADMIN/other:", allBoards);
          setBoards(allBoards);
        }
      } catch (err) {
        console.error("❌ BoardsPage error fetching boards:", err);
      }
    };

    if (currentUser) {
      fetchBoards();
    }
  }, [currentUser]);

  return (
    <div className="boards-page">
      <header className="boards-header">
        <h1>Task Boards</h1>
      </header>

      {currentUser?.role === "ROLE_ADMIN" && (
        <CreateBoardForm
          onBoardCreated={(newB) => {
            console.log("➕ New board created:", newB);
            setBoards((prev) => [newB, ...prev]);
          }}
        />
      )}

      <div className="boards-grid">
        {boards.map((board) => (
          <BoardCard key={board.id} board={board} />
        ))}
        {boards.length === 0 && <p>No boards available.</p>}
      </div>
    </div>
  );
};

export default BoardsPage;
