import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Bar, Pie } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  ArcElement,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend
} from 'chart.js';
import './StatsDashboard.css';

ChartJS.register(ArcElement, BarElement, CategoryScale, LinearScale, Tooltip, Legend);

const StatsDashboard = ({ boardId }) => {
  const [board, setBoard] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchBoard = async () => {
      try {
        const token = localStorage.getItem('authToken');
        const res = await axios.get(
          `http://localhost:8080/api/boards/${boardId}`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        setBoard(res.data);
      } catch (err) {
        console.error('Error fetching board for stats:', err);
        setError('Failed to load statistics.');
      }
    };
    fetchBoard();
  }, [boardId]);

  if (error) return <div className="alert alert-danger">{error}</div>;
  if (!board) return <div>Loading statistics…</div>;

  const allTasks = board.columns.flatMap(col =>
    col.tasks.map(t => ({ ...t, columnTitle: col.title }))
  );

  // Tasks by column
  const byCol = allTasks.reduce((acc, t) => {
    acc[t.columnTitle] = (acc[t.columnTitle] || 0) + 1;
    return acc;
  }, {});
  const colLabels = Object.keys(byCol);
  const colData = colLabels.map(l => byCol[l]);

  // Tasks by priority
  const byPrio = allTasks.reduce((acc, t) => {
    acc[t.priority] = (acc[t.priority] || 0) + 1;
    return acc;
  }, {});
  const prLabels = Object.keys(byPrio);
  const prData = prLabels.map(p => byPrio[p]);

  // Tasks by label
  const byLabel = {};
  allTasks.forEach(t =>
    (t.labels || []).forEach(l => {
      byLabel[l.name] = (byLabel[l.name] || 0) + 1;
    })
  );
  const lbLabels = Object.keys(byLabel);
  const lbData = lbLabels.map(n => byLabel[n]);

  return (
    <div className="stats-dashboard">
      <h5>📊 Board Statistics: « {board.title} »</h5>

      <div className="stats-section">
        <h6>Tasks per column</h6>
        <div className="chart-wrapper">
          <Bar
            data={{
              labels: colLabels,
              datasets: [{ label: 'Tasks', data: colData, backgroundColor: '#74b9ff' }]
            }}
            options={{
              responsive: false,
              maintainAspectRatio: false,
              scales: {
                y: { beginAtZero: true }
              }
            }}
            width={350}
            height={250}
          />
        </div>
      </div>

      <div className="stats-section">
        <h6>Distribution by priority</h6>
        <div className="chart-wrapper">
          <Pie
            data={{
              labels: prLabels,
              datasets: [{
                data: prData,
                backgroundColor: ['#ff7675', '#ffeaa7', '#55efc4', '#a29bfe']
              }]
            }}
            options={{ responsive: false, maintainAspectRatio: false }}
            width={300}
            height={300}
          />
        </div>
      </div>

      {lbLabels.length > 0 && (
        <div className="stats-section">
          <h6>Distribution by label</h6>
          <div className="chart-wrapper">
            <Pie
              data={{
                labels: lbLabels,
                datasets: [{
                  data: lbData,
                  backgroundColor: ['#fab1a0', '#81ecec', '#fdcb6e', '#dfe6e9']
                }]
              }}
              options={{ responsive: false, maintainAspectRatio: false }}
              width={300}
              height={300}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default StatsDashboard;
