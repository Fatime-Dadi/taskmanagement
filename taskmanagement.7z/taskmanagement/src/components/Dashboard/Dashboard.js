import React, { useEffect, useState } from "react";
import axios from "axios";
import StatsDashboard from "./StatsDashboard";

import "./StatsDashboard.css";
import "./Dashboard.css";

const Dashboard = () => {
  const [boards, setBoards] = useState([]);
  const [selectedBoardId, setSelectedBoardId] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchBoards = async () => {
      try {
        const token = localStorage.getItem("authToken");
        const res = await axios.get("http://localhost:8080/api/boards", {
          headers: { Authorization: `Bearer ${token}` },
        });
        const list = res.data.content || res.data;
        setBoards(list);
        if (list.length > 0) {
          setSelectedBoardId(list[0].id);
        }
      } catch (err) {
        console.error("Error fetching boards:", err);
        setError("Failed to load your boards.");
      }
    };
    fetchBoards();
  }, []);

  if (error) return <div className="alert alert-danger">{error}</div>;
  if (boards.length === 0) {
    return <div className="container mt-4">You don't have any boards.</div>;
  }

  return (
    <div className="container mt-4">
      <h1>Dashboard</h1>

      <div className="mb-4">
        <label htmlFor="boardSelect" className="form-label">
          Select a board:
        </label>
        <select
          id="boardSelect"
          className="form-select"
          value={selectedBoardId}
          onChange={(e) => setSelectedBoardId(e.target.value)}
        >
          {boards.map((b) => (
            <option key={b.id} value={b.id}>
              {b.title}
            </option>
          ))}
        </select>
      </div>

      {selectedBoardId && <StatsDashboard boardId={selectedBoardId} />}
    </div>
  );
};

export default Dashboard;
