import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import "./Login.css";
import axios from "axios";
import { useAuth } from "../../services/AuthContext";

const Login = () => {
  const [form, setForm] = useState({ email: "", password: "" });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState({ loading: false });
  const { authenticate } = useAuth();
  const navigate = useNavigate();

  const validate = async () => {
    const newErrors = {};
    if (!form.email) {
      newErrors.email = "Email is required";
    } else {
      try {
        const response = await axios.post("http://localhost:8080/api/checkEmail", { email: form.email });
        if (!response.data.exists) newErrors.email = "Invalid email address";
      } catch {
        newErrors.email = "Error verifying email";
      }
    }

    if (!form.password) {
      newErrors.password = "Password is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus({ loading: true });

    const isValid = await validate();
    if (!isValid) {
      setStatus({ loading: false });
      return;
    }

    try {
      console.log("[Login] Attempting authentication...");
      const result = await authenticate(form.email, form.password);
      console.log("[Login] Login result:", result);

      if (result?.requires2FA) {
        navigate("/verify-2fa", { state: { email: form.email } });
      } else {
         window.location.href = "/boards"; 
      }
    } catch (err) {
      console.error("[Login] Authentication failed:", err);
      setErrors({ general: "Incorrect email or password" });
      setStatus({ loading: false });
    }
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  return (
    <div className="connexion-container">
      <div className="account-card">
        <div className="account-header">
          <h1>Login</h1>
          <h3>Access your secure account</h3>
        </div>

        <form className="account-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              value={form.email}
              onChange={handleChange}
              required
            />
            {errors.email && <span className="text-danger">{errors.email}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              name="password"
              type="password"
              value={form.password}
              onChange={handleChange}
              required
            />
            {errors.password && <span className="text-danger">{errors.password}</span>}
          </div>

          <button
            type="submit"
            className="submit-btn"
            disabled={status.loading || !form.email || !form.password}
          >
            {status.loading ? "Logging in..." : "Log in"}
          </button>

          <div className="forgot-password">
            <Link to="/request-password-reset">Forgot your password?</Link>
          </div>

          {errors.general && (
            <div className="text-danger" style={{ textAlign: "center" }}>
              {errors.general}
            </div>
          )}
        </form>

        <div className="account-footer">
          <p>
            Don't have an account? <Link to="/register">Create one</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
