import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../services/AuthContext';
import axios from 'axios';
import './Verify2FA.css';

const Verify2FA = () => {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const { tempToken } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const email = location.state?.email;

  useEffect(() => {
    if (!email || !tempToken) {
      navigate('/login');
    }
  }, [email, tempToken, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await axios.post('http://localhost:8080/api/verify-2fa', {
        email,
        code,
        tempToken
      });

      localStorage.setItem('authToken', response.data.token);
      window.location.href = "/boards"; 
    } catch (err) {
      setError('Invalid or expired code. Please try again.');
      setLoading(false);
    }
  };

  const handleResendCode = async () => {
    try {
      await axios.post('http://localhost:8080/api/resend-2fa', { email });
      alert('A new code has been sent to your email address.');
    } catch (err) {
      setError('Error sending code. Please try again.');
    }
  };

  return (
    <div className="verify-2fa-container">
      <div className="verify-2fa-card">
        <h2>Two-Factor Authentication</h2>
        <p>We have sent a verification code to your email address.</p>
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="code">Verification Code</label>
            <input
              id="code"
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              required
              maxLength="6"
              placeholder="Enter the 6-digit code"
            />
          </div>

          {error && <div className="error-message">{error}</div>}

          <button type="submit" className="verify-btn" disabled={loading}>
            {loading ? 'Verifying...' : 'Verify'}
          </button>
        </form>

        <div className="resend-code">
          <p>Didn't receive a code?</p>
          <button onClick={handleResendCode} className="resend-btn">
            Resend Code
          </button>
        </div>
      </div>
    </div>
  );
};

export default Verify2FA;
