// src/components/Navbar/Navbar.jsx
import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { useAuth } from '../../services/AuthContext';
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import './Navbar.css';

const Navbar = () => {
  const [isCollapsed, setIsCollapsed] = useState(true);
  const { currentUser, logout } = useAuth();

  const toggleNavbar = () => {
    setIsCollapsed(!isCollapsed);
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-blue">
      <div className="container-fluid">
        <Link
          className="navbar-brand"
          to="/home"
          style={{ fontSize: '1.5rem', fontWeight: 'bold' }}
        >
          Task Manager
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          onClick={toggleNavbar}
          aria-controls="navbarNav"
          aria-expanded={!isCollapsed}
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div
          className={`collapse navbar-collapse ${isCollapsed ? '' : 'show'}`}
          id="navbarNav"
        >
          <ul className="navbar-nav ms-auto">

            {/* Always visible if logged in */}
            {currentUser?.role === 'PUBLIC' && (
              <li className="nav-item">
                <NavLink
                  to="/dashboard"
                  className={({ isActive }) =>
                    isActive ? 'active nav-link' : 'nav-link'
                  }
                >
                  <i className="fas fa-chart-pie"></i> Dashboard
                </NavLink>
              </li>
            )}

            {/* Only for ADMIN: manage boards */}
            {currentUser?.role === 'PUBLIC' && (
              <li className="nav-item">
                <NavLink
                  to="/boards"
                  className={({ isActive }) =>
                    isActive ? 'active nav-link' : 'nav-link'
                  }
                >
                  <i className="fas fa-table"></i> Boards
                </NavLink>
              </li>
            )}

            {/* User menu / Login / Logout */}
            {currentUser ? (
              <>
                <li className="nav-item d-flex align-items-center">
                  <span className="nav-link">
                    👤 {currentUser.firstName} {currentUser.lastName}
                  </span>
                </li>
                <li className="nav-item">
                  <button
                    className="nav-link btn btn-danger text-white"
                    onClick={logout}
                  >
                    Logout
                  </button>
                </li>
              </>
            ) : (
              <li className="nav-item">
                <NavLink
                  to="/login"
                  className={({ isActive }) =>
                    isActive
                      ? 'active nav-link btn btn-primary text-white'
                      : 'nav-link btn btn-primary text-white'
                  }
                >
                  <i className="fas fa-sign-in-alt"></i> Login
                </NavLink>
              </li>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
