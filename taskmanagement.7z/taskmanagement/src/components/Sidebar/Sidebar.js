import React, { useEffect, useState } from "react";
import { NavLink, Link } from "react-router-dom";
import { useAuth } from "../../services/AuthContext";
import axios from "axios";
import {
  FaTasks,
  FaChartPie,
  FaTable,
  FaUsers,
  FaUserCircle,
  FaSignOutAlt,
  FaSignInAlt,
} from "react-icons/fa";
import "./Sidebar.css";

const Sidebar = () => {
  const { currentUser, logout } = useAuth();
  const [boards, setBoards] = useState([]);

  // 🔍 Console debug
  console.log("➡️ currentUser:", currentUser);

  const hasRole = (role) => {
  const result = currentUser?.role === role;
  console.log(`🔎 hasRole(${role}):`, result);
  return result;
};


  useEffect(() => {
    (async () => {
      try {
        const token = localStorage.getItem("authToken");
        const res = await axios.get("http://localhost:8080/api/boards", {
          headers: { Authorization: `Bearer ${token}` },
        });
        console.log("✅ Fetched boards:", res.data.content || res.data);
        setBoards(res.data.content || res.data);
      } catch (err) {
        console.error("❌ Error fetching boards:", err);
      }
    })();
  }, []);

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <Link to="/home" className="sidebar-brand">
          <FaTasks /> Task Manager
        </Link>
      </div>

      <nav className="sidebar-nav">
        {hasRole("ROLE_ADMIN") && (
          <NavLink to="/dashboard" className="nav-link">
            <FaChartPie /> Dashboard
          </NavLink>
        )}

        <NavLink to="/boards" className="nav-link">
          <FaTable /> All Boards
        </NavLink>

        {hasRole("ROLE_ADMIN") && (
          <NavLink to="/users" className="nav-link">
            <FaUsers /> User Management
          </NavLink>
        )}
      </nav>

      <div className="sidebar-footer">
        {currentUser ? (
          <>
            <div className="user-info">
              <FaUserCircle />
              <span className="user-name">
                {currentUser.firstName} {currentUser.lastName}
              </span>
            </div>
            <button className="logout-btn" onClick={logout}>
              <FaSignOutAlt /> Logout
            </button>
          </>
        ) : (
          <NavLink to="/login" className="login-btn">
            <FaSignInAlt /> Login
          </NavLink>
        )}
      </div>
    </aside>
  );
};

export default Sidebar;
