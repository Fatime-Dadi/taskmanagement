import React from 'react';
import './BoardDetail.css';

const CommentsList = ({ comments }) => {
  return (
    <div className="comment-list">
      {comments.length === 0 ? (
        <p className="small text-muted">No comments</p>
      ) : (
        comments.map(c => (
          <div key={c.id} className="comment-card small mb-1">
            <strong>{c.author.firstName} {c.author.lastName}</strong>{' '}
            <em>{new Date(c.createdAt).toLocaleString()}</em>
            <p className="mb-0">{c.content}</p>
          </div>
        ))
      )}
    </div>
  );
};

export default CommentsList;
