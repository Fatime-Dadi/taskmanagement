import React, { useState } from 'react';
import axios from 'axios';
import './BoardDetail.css';

const CreateColumnForm = ({ boardId, onColumnCreated }) => {
  const [title, setTitle] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async e => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Title is required.');
      return;
    }
    try {
      const token = localStorage.getItem('authToken');
      const res = await axios.post(
        'http://localhost:8080/api/columns',
        { title, boardId },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      onColumnCreated({ ...res.data, tasks: [] });
      setTitle('');
      setError('');
    } catch {
      setError('Unable to create column.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="mb-3 create-column-form">
      <input
        type="text"
        className="form-control mb-1"
        placeholder="New column…"
        value={title}
        onChange={e => setTitle(e.target.value)}
      />
      {error && <div className="text-danger small mb-1">{error}</div>}
      <button type="submit" className="btn btn-secondary w-100">
        + Add Column
      </button>
    </form>
  );
};

export default CreateColumnForm;
