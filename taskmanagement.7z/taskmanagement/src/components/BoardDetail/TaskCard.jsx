import React, { useState, useEffect } from 'react';
import CommentsList from './CommentsList';
import CreateCommentForm from './CreateCommentForm';
import EditTaskModal from './EditTaskModal';
import { FaGripLines, FaEdit } from 'react-icons/fa';
import api from '../../services/api';
import './TaskCard.css';

const TaskCard = ({ task, onTaskUpdated }) => {
  const [showEditModal, setShowEditModal] = useState(false);
  const [comments, setComments] = useState([]);

  // Charger les commentaires au montage ou quand task.id change
  useEffect(() => {
    let isMounted = true;
    (async () => {
      try {
        const token = localStorage.getItem('authToken');
        const res = await api.get(`/comments/task/${task.id}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (isMounted) setComments(res.data);
      } catch (err) {
        console.error('Failed to load comments', err);
      }
    })();
    return () => { isMounted = false; };
  }, [task.id]);

  // Ajouter un nouveau commentaire localement
  const handleCommentCreated = newComment => {
    setComments(prev => [...prev, newComment]);
  };

  // Mettre à jour la tâche, fermer le modal, puis recharger la page
  const handleTaskUpdatedLocally = updated => {
    onTaskUpdated({
      ...updated,
      id: Number(updated.id),
      columnId: Number(task.columnId),
    });
    setShowEditModal(false);
    // recharge complète pour afficher immédiatement la tâche modifiée
    window.location.reload();
  };

  return (
    <>
      <div className="task-card">
        <span className="drag-handle" title="Drag to move">
          <FaGripLines />
        </span>

        <h6 className="task-title">{task.title}</h6>
        <button className="btn-edit" onClick={() => setShowEditModal(true)}>
          <FaEdit />
        </button>

        {task.assignedUser && (
          <small className="assigned-user">
            👤 {task.assignedUser.firstName} {task.assignedUser.lastName}
          </small>
        )}

        <div className="task-labels">
          {task.labels?.map(l => (
            <span key={l.id} className="badge" style={{ backgroundColor: l.color }}>
              {l.name}
            </span>
          ))}
        </div>

        {task.description && <p className="task-desc">{task.description}</p>}

        <CommentsList comments={comments} />

        <CreateCommentForm taskId={task.id} onCommentCreated={handleCommentCreated} />
      </div>

      {showEditModal && (
        <EditTaskModal
          task={task}
          columnId={task.columnId}
          onClose={() => setShowEditModal(false)}
          onTaskUpdated={handleTaskUpdatedLocally}
        />
      )}
    </>
  );
};

export default TaskCard;
