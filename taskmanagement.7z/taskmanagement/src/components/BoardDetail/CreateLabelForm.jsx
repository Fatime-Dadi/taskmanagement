// src/components/BoardDetail/CreateLabelForm.jsx
import React, { useState } from 'react';
import axios from 'axios';
import './CreateLabelForm.css';

const CreateLabelForm = ({ onLabelCreated }) => {
  const [name, setName] = useState('');
  const [color, setColor] = useState('#000000');
  const [error, setError] = useState('');

  const handleSubmit = async e => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Label name is required.');
      return;
    }
    try {
      const token = localStorage.getItem('authToken');
      // Relative call using the defined proxy
      await axios.post('/api/labels', { name, color }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      onLabelCreated();
      setName('');
      setError('');
    } catch (err) {
      console.error('Label creation error:', err);
      setError('Failed to create label.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="create-label-form">
      <input
        type="text"
        placeholder="Label name"
        className="form-control"
        value={name}
        onChange={e => setName(e.target.value)}
      />
      <input
        type="color"
        value={color}
        onChange={e => setColor(e.target.value)}
      />
      {error && <div className="text-danger small">{error}</div>}
      <button type="submit" className="btn btn-sm btn-primary">
        Create
      </button>
    </form>
  );
};

export default CreateLabelForm;
