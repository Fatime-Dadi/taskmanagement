import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { useAuth } from "../../services/AuthContext";
import ColumnCard from "./ColumnCard";
import CreateColumnForm from "./CreateColumnForm";
import LabelManager from "./LabelManager";
import "./BoardDetail.css";

const BoardDetail = () => {
  const { currentUser } = useAuth();
  const { id } = useParams();
  const [board, setBoard] = useState(null);
  const [showLabelManager, setShowLabelManager] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  // Fetch board data
  useEffect(() => {
    if (isDragging) return;
    const fetchBoard = async () => {
      const token = localStorage.getItem("authToken");
      const { data } = await axios.get(
        `http://localhost:8080/api/boards/${id}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setBoard((prev) => {
        if (!prev || JSON.stringify(prev) !== JSON.stringify(data)) {
          return data;
        }
        return prev;
      });
    };
    fetchBoard();
  }, [id, isDragging]);

  const handleDragEnd = async ({ source, destination, draggableId }) => {
    setIsDragging(false);
    if (!destination || (source.droppableId === destination.droppableId && source.index === destination.index)) {
      return;
    }

    const newColumns = board.columns.map((col) => ({ ...col, tasks: Array.from(col.tasks) }));
    const fromCol = newColumns.find((c) => String(c.id) === source.droppableId);
    const toCol = newColumns.find((c) => String(c.id) === destination.droppableId);
    if (!fromCol || !toCol) return;

    // Move the task locally
    const [moved] = fromCol.tasks.splice(source.index, 1);
    toCol.tasks.splice(destination.index, 0, moved);
    setBoard((prev) => ({ ...prev, columns: newColumns }));

    // Persist change
    if (fromCol.id !== toCol.id) {
      try {
        const token = localStorage.getItem("authToken");
        await axios.post(
          `http://localhost:8080/api/tasks/${draggableId}/move`,
          {},
          { params: { newColumnId: toCol.id }, headers: { Authorization: `Bearer ${token}` } }
        );
      } catch (err) {
        console.error("Error during move API call", err);
      }
    }
  };

  if (!board) return <div className="board-loading">Loading…</div>;

  return (
    <div className="board-detail">
      <header>
        <h2>{board.title}</h2>
        <p>{board.description}</p>
      </header>

      {currentUser.role === "ROLE_ADMIN" && (
        <>
          <button className="btn btn-sm btn-outline-secondary mb-2" onClick={() => setShowLabelManager(true)}>
            🏷️ Manage Labels
          </button>
          {showLabelManager && (
            <div className="modal-overlay" onClick={() => setShowLabelManager(false)}>
              <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                <LabelManager onClose={() => setShowLabelManager(false)} />
              </div>
            </div>
          )}

          <CreateColumnForm
            boardId={board.id}
            onColumnCreated={(col) => setBoard((prev) => ({
              ...prev,
              columns: [...prev.columns, { ...col, tasks: [] }]
            }))}
          />
        </>
      )}

      <DragDropContext
        onDragStart={() => setIsDragging(true)}
        onDragEnd={handleDragEnd}
      >
        <div className="board-columns">
          {board.columns.map((col) => (
            <ColumnCard
              key={col.id}
              column={col}
              onTaskUpdated={(updated) => {
                if (isDragging) return;
                setBoard((prev) => {
                  const columns = prev.columns.map((c) => {
                    if (c.id !== updated.columnId) return c;
                    return {
                      ...c,
                      tasks: c.tasks.map((t) => (t.id === updated.id ? updated : t))
                    };
                  });
                  return { ...prev, columns };
                });
              }}
              onTaskCreated={(newTask) => {
                setBoard((prev) => {
                  const columns = prev.columns.map((c) => {
                    if (c.id !== newTask.columnId) return c;
                    return { ...c, tasks: [...c.tasks, newTask] };
                  });
                  return { ...prev, columns };
                });
              }}
            />
          ))}
        </div>
      </DragDropContext>
    </div>
  );
};

export default BoardDetail; 