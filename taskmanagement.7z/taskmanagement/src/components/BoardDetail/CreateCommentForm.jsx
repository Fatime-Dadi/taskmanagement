import React, { useState } from 'react';
import axios from 'axios';
import './BoardDetail.css';

const CreateCommentForm = ({ taskId, onCommentCreated }) => {
  const [content, setContent] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async e => {
    e.preventDefault();
    if (!content.trim()) {
      setError('Comment cannot be empty.');
      return;
    }
    try {
      const res = await axios.post(
        'http://localhost:8080/api/comments',
        { taskId, content },
        {
          headers: { Authorization: `Bearer ${localStorage.getItem('authToken')}` }
        }
      );
      setTimeout(() => onCommentCreated(res.data), 0);
  setContent('');
      setError('');
    } catch {
      setError('Failed to post comment.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="mt-2 comment-form">
      <textarea
        rows="2"
        className="form-control mb-1"
        placeholder="Add a comment…"
        value={content}
        onChange={e => setContent(e.target.value)}
      />
      {error && <div className="text-danger small mb-1">{error}</div>}
      <button type="submit" className="btn btn-sm btn-outline-primary w-100">
        Post
      </button>
    </form>
  );
};

export default CreateCommentForm;
