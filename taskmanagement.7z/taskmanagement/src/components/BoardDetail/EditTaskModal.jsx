import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import './EditTaskModal.css';

const EditTaskModal = ({ task, columnId, onClose, onTaskUpdated }) => {
  const [form, setForm] = useState({
    title: '',
    description: '',
    priority: 'MEDIUM',
    assignedUserId: '',
    labelIds: [],
  });
  const [users, setUsers] = useState([]);
  const [allLabels, setAllLabels] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    setForm({
      title: task.title || '',
      description: task.description || '',
      priority: task.priority || 'MEDIUM',
      assignedUserId: task.assignedUser?.id?.toString() || '',
      labelIds: task.labels?.map(l => l.id) || [],
    });

    api.get('/users').then(res => setUsers(res.data)).catch(console.error);
    api.get('/labels').then(res => setAllLabels(res.data)).catch(console.error);
  }, [task]);

  const handleChange = e => {
    const { name, value, selectedOptions } = e.target;
    if (name === 'labelIds') {
      const vals = Array.from(selectedOptions).map(o => Number(o.value));
      setForm(f => ({ ...f, labelIds: vals }));
    } else {
      setForm(f => ({ ...f, [name]: value }));
    }
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    const payload = {
      title: form.title.trim(),
      description: form.description.trim(),
      priority: form.priority,
      assignedUserId: form.assignedUserId || null,
      labelIds: form.labelIds,
    };

    try {
      const res = await api.put(`/tasks/${task.id}`, payload);
      onTaskUpdated(res.data); // TaskCard réincrémente columnId
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.message || err.message);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <h5>Edit Task</h5>
        {error && <div className="text-danger small mb-2">{error}</div>}
        <form onSubmit={handleSubmit} className="edit-task-form">
          <input name="title" className="form-control mb-2" placeholder="Title" value={form.title} onChange={handleChange} />
          <textarea name="description" className="form-control mb-2" rows="3" placeholder="Description" value={form.description} onChange={handleChange} />
          <select name="priority" className="form-select mb-2" value={form.priority} onChange={handleChange}>
            <option value="LOW">Low</option>
            <option value="MEDIUM">Medium</option>
            <option value="HIGH">High</option>
          </select>
          <select name="assignedUserId" className="form-select mb-2" value={form.assignedUserId} onChange={handleChange}>
            <option value="">— None —</option>
            {users.map(u => <option key={u.id} value={u.id}>{u.firstName} {u.lastName}</option>)}
          </select>
          <label className="form-label">Labels</label>
          <select name="labelIds" multiple className="form-select mb-3" size={Math.min(6, allLabels.length)} value={form.labelIds.map(String)} onChange={handleChange}>
            {allLabels.map(l => (
              <option key={l.id} value={l.id} style={{ backgroundColor: l.color, color: '#fff' }}>{l.name}</option>
            ))}
          </select>
          <div className="modal-actions">
            <button type="button" className="btn btn-outline-light" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary">Save</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditTaskModal;
