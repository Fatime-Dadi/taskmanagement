// src/components/BoardDetail/LabelSelector.jsx
import React, { useEffect, useState } from 'react';
import api from '../../services/api';
import './LabelSelector.css';

const LabelSelector = ({ taskData, currentLabels, onLabelsUpdated, columnId }) => {
  const [allLabels, setAllLabels] = useState([]);
  const [editingLabelId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({ name: '', color: '' });
  const [error, setError] = useState('');

  // ➊ Load all labels
  useEffect(() => {
    fetchLabels();
  }, []);

  const fetchLabels = async () => {
    try {
      const res = await api.get('/labels');
      setAllLabels(res.data);
      setError('');
    } catch (err) {
      console.error(err);
      setError('Failed to load labels.');
    }
  };

  // ➋ Assign/unassign label to task
  const toggleLabel = async label => {
    const isActive = currentLabels.some(l => l.id === label.id);
    const updated = isActive
      ? currentLabels.filter(l => l.id !== label.id)
      : [...currentLabels, label];

    const payload = {
      title: taskData.title,
      description: taskData.description,
      dueDate: taskData.dueDate,
      priority: taskData.priority,
      columnId,
      assignedUserId: taskData.assignedUser?.id || null,
      labelIds: updated.map(l => l.id)
    };

    try {
      const res = await api.put(`/tasks/${taskData.id}`, payload);
      onLabelsUpdated(res.data.labels || []);
      setError('');
    } catch {
      setError('Failed to update labels.');
    }
  };

  // ➌ Start inline editing
  const startEdit = label => {
    setEditingId(label.id);
    setEditForm({ name: label.name.trim(), color: label.color });
  };

  // ➍ Save label name/color update
  const saveEdit = async () => {
    try {
      await api.put(`/labels/${editingLabelId}`, {
        name: editForm.name,
        color: editForm.color
      });
      setEditingId(null);
      fetchLabels();
    } catch {
      setError('Failed to edit label.');
    }
  };

  return (
    <div className="label-selector">
      {error && <div className="text-danger small mb-2">{error}</div>}

      <div className="labels-container">
        {allLabels.map(label => {
          const active = currentLabels.some(l => l.id === label.id);
          const isEditing = editingLabelId === label.id;

          return (
            <div key={label.id} className="label-item">
              {/* Clickable badge to assign/unassign */}
              <span
                className={`label-badge ${active ? 'active' : ''}`}
                style={{ backgroundColor: label.color }}
                onClick={() => toggleLabel(label)}
              >
                {label.name}
              </span>

              {/* Edit name & color button */}
              <button
                className="btn-edit-color"
                title="⚙️ Edit this label"
                onClick={() => startEdit(label)}
              >✏️</button>

              {/* Inline edit form */}
              {isEditing && (
                <div className="label-edit-form">
                  <input
                    type="text"
                    name="name"
                    value={editForm.name}
                    onChange={e => setEditForm(f => ({ ...f, name: e.target.value }))}
                    className="form-control label-name-input"
                  />
                  <input
                    type="color"
                    name="color"
                    value={editForm.color}
                    onChange={e => setEditForm(f => ({ ...f, color: e.target.value }))}
                    className="label-color-input"
                  />
                  <button
                    className="btn btn-sm btn-success ms-1"
                    onClick={saveEdit}
                  >✓</button>
                  <button
                    className="btn btn-sm btn-outline-danger ms-1"
                    onClick={() => setEditingId(null)}
                  >✕</button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default LabelSelector;
