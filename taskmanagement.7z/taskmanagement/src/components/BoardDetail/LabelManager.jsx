import React, { useEffect, useState } from 'react';
import api from '../../services/api';
import CreateLabelForm from './CreateLabelForm';
import './LabelManager.css';

const LabelManager = ({ onClose }) => {
  const [labels, setLabels] = useState([]);
  const [error, setError] = useState('');

  const fetchLabels = async () => {
    try {
      const res = await api.get('/labels');
      setLabels(res.data);
      setError('');
    } catch (err) {
      console.error('fetchLabels error:', err);
      setError('Failed to load labels.');
    }
  };

  useEffect(() => {
    fetchLabels();

    const handleKey = (e) => {
      if (e.key === 'Escape') onClose();
    };

    document.body.style.overflow = 'hidden';
    document.addEventListener('keydown', handleKey);

    return () => {
      document.body.style.overflow = 'auto';
      document.removeEventListener('keydown', handleKey);
    };
  }, [onClose]);

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this label?")) return;
    try {
      await api.delete(`/labels/${id}`);
      fetchLabels();
    } catch (err) {
      console.error('Label deletion error:', err);
      setError('Failed to delete label.');
    }
  };

  return (
    <div className="label-modal-overlay" onClick={onClose}>
      <div className="label-modal" onClick={(e) => e.stopPropagation()}>
        <button className="close-x" onClick={onClose}>X</button>

        <div className="label-manager">
          <h5>🏷️ Manage Labels</h5>

          {error && <div className="error">{error}</div>}

          <CreateLabelForm onLabelCreated={fetchLabels} />

          {labels.length === 0 ? (
            <p className="text-muted small">No labels defined.</p>
          ) : (
            <div className="labels-container">
              {labels.map(label => (
                <div key={label.id} className="label-item">
                  <span
                    className="label-badge"
                    style={{ backgroundColor: label.color }}
                  >
                    {label.name}
                  </span>
                  <button
                    className="delete-label-btn"
                    title={`Delete "${label.name}"`}
                    onClick={() => handleDelete(label.id)}
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LabelManager;
