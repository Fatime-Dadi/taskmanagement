import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './BoardDetail.css';

const CreateTaskForm = ({ columnId, onTaskCreated }) => {
  const [form, setForm] = useState({ title: '', description: '', priority: 'MEDIUM', assignedUserId: '' });
  const [users, setUsers] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    axios.get('http://localhost:8080/api/users', { headers: { Authorization: `Bearer ${localStorage.getItem('authToken')}` } })
      .then(res => setUsers(res.data))
      .catch(() => {});
  }, []);

  const handleChange = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title.trim()) {
      setError('Title is required.');
      return;
    }
    try {
      const payload = { ...form, columnId, assignedUserId: form.assignedUserId || null };
      const res = await axios.post('http://localhost:8080/api/tasks', payload, { headers: { Authorization: `Bearer ${localStorage.getItem('authToken')}` } });
      setError('');
      // Delay callback to allow DnD registration
      setTimeout(() => onTaskCreated({ ...res.data, columnId }), 0);
      setForm({ title: '', description: '', priority: 'MEDIUM', assignedUserId: '' });
    } catch {
      setError('Failed to create task.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="mt-3 create-task-form">
      <input name="title" className="form-control mb-1" placeholder="Card title…" value={form.title} onChange={handleChange} />
      <textarea name="description" className="form-control mb-1" rows="2" placeholder="Description…" value={form.description} onChange={handleChange} />
      <select name="priority" className="form-select mb-1" value={form.priority} onChange={handleChange}>
        <option value="LOW">Low</option>
        <option value="MEDIUM">Medium</option>
        <option value="HIGH">High</option>
      </select>
      <select name="assignedUserId" className="form-select mb-2" value={form.assignedUserId} onChange={handleChange}>
        <option value="">— None —</option>
        {users.map((u) => <option key={u.id} value={u.id}>{u.firstName} {u.lastName}</option>)}
      </select>
      {error && <div className="text-danger small mb-1">{error}</div>}
      <button type="submit" className="btn btn-primary w-100 btn-sm">+ Add Card</button>
    </form>
  );
};

export default CreateTaskForm;