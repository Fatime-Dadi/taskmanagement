import React from 'react';
import { Droppable, Draggable } from '@hello-pangea/dnd';
import TaskCard from './TaskCard';
import CreateTaskForm from './CreateTaskForm';

const ColumnCard = ({ column, onTaskUpdated, onTaskCreated }) => (
  <Droppable droppableId={column.id.toString()}>
    {(provided, snapshot) => (
      <div
        className={`column-container ${snapshot.isDraggingOver ? 'drag-over' : ''}`}
        ref={provided.innerRef}
        {...provided.droppableProps}
      >
        <div className="column-header">{column.title}</div>
        <div className="task-list">
          {column.tasks.map((task, index) => (
            <Draggable key={task.id} draggableId={task.id.toString()} index={index}>
              {(providedDraggable, snapshotDraggable) => (
                <div
                  ref={providedDraggable.innerRef}
                  {...providedDraggable.draggableProps}
                  {...providedDraggable.dragHandleProps}
                  className={`task-wrapper ${snapshotDraggable.isDragging ? 'dragging' : ''}`}
                >
                  <TaskCard task={task} onTaskUpdated={onTaskUpdated} />
                </div>
              )}
            </Draggable>
          ))}
          {provided.placeholder}
        </div>
        <CreateTaskForm columnId={column.id} onTaskCreated={onTaskCreated} />
      </div>
    )}
  </Droppable>
);

export default ColumnCard;