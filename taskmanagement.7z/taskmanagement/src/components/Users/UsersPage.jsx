import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './UsersPage.css';

const AVAILABLE_ROLES = ['PUBLIC', 'ROLE_FORMATEUR', 'ROLE_ADMIN', 'ROLE_ETUDIANT'];

const UsersPage = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busyIds, setBusyIds] = useState({});
  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 2;

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const token = localStorage.getItem('authToken');
      const res = await axios.get('/api/users', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setUsers(res.data);
    } catch (err) {
      console.error('Error loading users:', err);
    } finally {
      setLoading(false);
    }
  };

  const setBusy = (id, flag) =>
    setBusyIds(prev => ({ ...prev, [id]: flag }));

  const toggleActivation = async (id, makeActive) => {
    setBusy(id, true);
    try {
      const token = localStorage.getItem('authToken');
      await axios.put(`/api/activateDeactivateUser/${id}`, null, {
        params: { isActive: makeActive },
        headers: { Authorization: `Bearer ${token}` }
      });
      setUsers(u =>
        u.map(x => (x.id === id ? { ...x, valid: makeActive } : x))
      );
    } catch (err) {
      console.error('Activation error:', err);
    } finally {
      setBusy(id, false);
    }
  };

  const updateRole = async (id, newRole) => {
    setBusy(id, true);
    try {
      const token = localStorage.getItem('authToken');
      await axios.put(`/api/changeUserRole/${id}`, newRole, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'text/plain'
        }
      });
      setUsers(u =>
        u.map(x => (x.id === id ? { ...x, role: newRole } : x))
      );
    } catch (err) {
      console.error('Role update error:', err);
    } finally {
      setBusy(id, false);
    }
  };

  const deleteUser = async (id) => {
    if (!window.confirm("Delete this user?")) return;
    setBusy(id, true);
    try {
      const token = localStorage.getItem('authToken');
      await axios.delete(`/api/deleteUser/${id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setUsers(u => u.filter(x => x.id !== id));
    } catch (err) {
      console.error('Delete error:', err);
    } finally {
      setBusy(id, false);
    }
  };

  // FILTER + PAGINATION
  const filteredUsers = users.filter(u =>
    `${u.firstName} ${u.lastName} ${u.email}`.toLowerCase().includes(search.toLowerCase())
  );

  const totalPages = Math.ceil(filteredUsers.length / itemsPerPage);
  const indexOfLast = currentPage * itemsPerPage;
  const indexOfFirst = indexOfLast - itemsPerPage;
  const currentUsers = filteredUsers.slice(indexOfFirst, indexOfLast);

  const handleSearchChange = (e) => {
    setSearch(e.target.value);
    setCurrentPage(1);
  };

  if (loading) {
    return (
      <div className="text-center mt-5">
        <div className="spinner-border" role="status">
          <span className="visually-hidden">Loading…</span>
        </div>
      </div>
    );
  }

  return (
    <div className="container user-mgmt-container">
      <div className="card shadow-sm mb-4">
        <div className="card-body">
          <h1 className="card-title mb-4">User Management</h1>

          {/* Search field */}
          <div className="mb-3 text-center">
            <input
              type="text"
              className="form-control search-input"
              placeholder="Search by name or email..."
              value={search}
              onChange={handleSearchChange}
            />
            <p className="text-muted mt-2">
              {filteredUsers.length} user{filteredUsers.length !== 1 ? 's' : ''} found
            </p>
          </div>

          {/* Table */}
          <table className="table table-hover align-middle">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th className="text-end">Actions</th>
              </tr>
            </thead>
            <tbody>
              {currentUsers.map(u => (
                <tr key={u.id} className={u.valid ? '' : 'table-danger'}>
                  <td>{u.firstName} {u.lastName}</td>
                  <td>{u.email}</td>
                  <td>
                    <select
                      className="form-select form-select-sm"
                      value={u.role}
                      disabled={busyIds[u.id]}
                      onChange={e => updateRole(u.id, e.target.value)}
                    >
                      {AVAILABLE_ROLES.map(r => (
                        <option key={r} value={r}>{r.replace('ROLE_', '')}</option>
                      ))}
                    </select>
                  </td>
                  <td>
                    <span className={`badge ${u.valid ? 'bg-success' : 'bg-secondary'}`}>
                      {u.valid ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="text-end">
                    <button
                      className={`btn btn-sm ${u.valid ? 'btn-outline-warning' : 'btn-outline-success'} me-2`}
                      disabled={busyIds[u.id]}
                      onClick={() => toggleActivation(u.id, !u.valid)}
                    >
                      {u.valid ? 'Deactivate' : 'Activate'}
                    </button>
                    <button
                      className="btn btn-sm btn-outline-danger"
                      disabled={busyIds[u.id]}
                      onClick={() => deleteUser(u.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
              {filteredUsers.length === 0 && (
                <tr>
                  <td colSpan="5" className="text-center py-4">
                    No users found
                  </td>
                </tr>
              )}
            </tbody>
          </table>

          {/* Pagination */}
          {filteredUsers.length > itemsPerPage && (
            <div className="pagination-controls mt-4 d-flex justify-content-center">
              <button
                className="btn btn-outline-primary me-2"
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(prev => prev - 1)}
              >
                Previous
              </button>

              {[...Array(totalPages)].map((_, i) => (
                <button
                  key={i}
                  className={`btn btn-sm mx-1 ${currentPage === i + 1 ? 'btn-primary' : 'btn-outline-secondary'}`}
                  onClick={() => setCurrentPage(i + 1)}
                >
                  {i + 1}
                </button>
              ))}

              <button
                className="btn btn-outline-primary ms-2"
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage(prev => prev + 1)}
              >
                Next
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UsersPage;
