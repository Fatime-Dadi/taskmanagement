import React from 'react';
import './Home.css';
import '@fortawesome/fontawesome-free/css/all.min.css';




const Home = () => {
  return (
    <>
      <section className="hero">
        <div className="container d-flex flex-column flex-md-row justify-content-between align-items-center text-center text-md-start">
          <div className="hero-text">
            <h1><i className="fas fa-rocket me-2 text-primary"></i>Boost Your Productivity</h1>
            <p style={{ color: 'gr' }}
            >Manage your tasks efficiently with our all-in-one solution.</p>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="about py-5">
        <div className="container">
          <h2><i className="fas fa-info-circle me-2 text-secondary"></i>About Us</h2>
          <p>
            We're a passionate team focused on building intuitive and powerful task management tools. Our goal is to simplify your workflow and empower you to focus on what truly matters.
          </p>
        </div>
      </section>

      {/* Objectives Section */}
      <section className="objectives py-5">
        <div className="container">
          <h2><i className="fas fa-bullseye me-2 text-danger"></i>Our Mission</h2>
          <ul>
            <li><i className="fas fa-check-circle text-success me-2"></i>Deliver a seamless and user-friendly task management experience.</li>
            <li><i className="fas fa-check-circle text-success me-2"></i>Help you stay organized and increase your productivity.</li>
            <li><i className="fas fa-check-circle text-success me-2"></i>Encourage collaboration and teamwork through smart features.</li>
          </ul>
        </div>
      </section>

      {/* Team Section */}
      <section className="team py-5">
        <div className="container">
          <h2><i className="fas fa-users me-2 text-info"></i>Meet the Team</h2>
          <p>
            Our diverse team includes developers, designers, and project managers committed to excellence. Together, we create solutions tailored to real-world productivity challenges.
          </p>
        </div>
      </section>

      {/* Values Section */}
      <section className="values py-5">
        <div className="container">
          <h2><i className="fas fa-heart me-2 text-danger"></i>Our Core Values</h2>
          <ul>
            <li><i className="fas fa-handshake text-warning me-2"></i><strong>Integrity</strong>: Transparency and trust are at our core.</li>
            <li><i className="fas fa-lightbulb text-primary me-2"></i><strong>Innovation</strong>: We embrace change and seek to improve constantly.</li>
            <li><i className="fas fa-user-check text-success me-2"></i><strong>Customer Focus</strong>: Your satisfaction drives our decisions.</li>
          </ul>
        </div>
      </section>
    </>
  );
};

export default Home;
