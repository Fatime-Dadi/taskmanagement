import React, { useState } from 'react';
import axios from 'axios';
import './RequestPasswordReset.css';

const RequestPasswordReset = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMsg('');
    setError('');
    setLoading(true);
    try {
      const res = await axios.post('http://localhost:8080/api/request-password-reset', { email });
      setMsg('✅ A password reset link has been sent to your email.');
    } catch (err) {
      setError("❌ Failed to send email. Please check the provided address.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="reset-password-container">
      <h2>Password Reset</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="email"
          required
          placeholder="Enter your email address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <button type="submit" disabled={loading}>
          {loading ? "Please wait..." : "Send Reset Link"}
        </button>
        {msg && <p className="success-message">{msg}</p>}
        {error && <p className="error-message">{error}</p>}
      </form>
    </div>
  );
};

export default RequestPasswordReset;
